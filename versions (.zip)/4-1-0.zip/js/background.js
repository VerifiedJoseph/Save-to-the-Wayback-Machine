	
	// Hard coded options
	var valid = {
		url: true, // URL is vaild
		disallowMatch: false, // Robots.txt disallow match
		metaTagFound: false
	}
	
	var options = {
		regex: /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,20}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi,
		regexIPv4: /^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/,
		protocolBlackList: ['chrome:','chrome-extension:','ftp:','file:'],
		hostNameBlackList: ['web.archive.org','127.0.0.1'],
		saveUrl: "https://web.archive.org/save/",
		calendarUrl: "https://web.archive.org/web/*/",
		apiUrl: "https://archive.org/wayback/available?url=",
		alertSounds: ['served-alert.mp3','job-done.mp3']
	}
	
	var defaultUserOptions = {
		//pagesArchived: 0, // Number of pages archived  
		logNumberArchived: true, // Log number of pages archived
		
		// Context Menus
		contextMenu: true, // Show 'Archive this' link is the context menu
		contextMenuCreated: false, // Has this context menu be created
		contextMenuNote: true, // Display note if a page cannot be archived via the context menu
		
		// Notifications
		notePlayAlert: false, // Play alert sound when a notification is displayed.
		noteAlertSound: 0, // Default Alert sound.
		
		// Scan robots.txt file
		scanRobotsFile: false // Scan each website's robots.txt file 
	}
	
	// User options from chrome.storage
	var userOptions = {};
		
	// Listener for then the extension is installed or updated
	chrome.runtime.onInstalled.addListener(function(details) {
    
		if(details.reason == "install") {
			console.log(getTime() + "This is a first install!");
		
			fetchUserOptions(function() { // Fetch user options and run contextMenus() function 
				contextMenus(true);
			});
			
		} else if(details.reason == "update") {
			var thisVersion = chrome.runtime.getManifest().version;
			console.log(getTime() + "Updated from " + details.previousVersion + " to " + thisVersion + "!");
			
			fetchUserOptions(function() { // Fetch user options and run contextMenus() function
				contextMenus(true);
			});
			
		}
	});
	
	// Listener for then the extension is started
	chrome.runtime.onStartup.addListener(function() {
	
		fetchUserOptions(function() { // Fetch user options and run contextMenus() function  
			contextMenus(true);
		});
		
	});
	
	// Listener for then the storage has changed
	chrome.storage.onChanged.addListener(function(changes, namespace) {

		fetchUserOptions(function() { // Fetch user options and run contextMenus() function
			contextMenus();
		});

	});
	
	// Listener for on click of the context menu link
	chrome.contextMenus.onClicked.addListener(function(info, tab) {
		
		vaildate(tab.url, function() {
			
			if(valid['url'] == true && valid['disallowMatch'] == false) { // URL is vaild, log number 

				logNumber();
				openTab(tab.url); // Open save URL

			} else {
			
				notifyUser(tab.url); // Show notification
				notifyUserSound(); // Play sound, if enabled
			
			}
			
		});		
	});
	
	// Listener for messages from pop.js
	chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
		var responseLog;
		var responseVariable;
		
		// Log request
		console.log(getTime() + 'Request | ' + request.name + ' | variables : '+ request.variable);
			
		if(request.name == 'logNumber') {
				
			logNumber();
			responseVariable = valid['url'];	

			var logText = 'Function '+ request.name +'() run'; 
			
			sendResponse({name: 'logNumber', log: logText, variable: valid});
			
			// Log Response
			console.log(getTime() + 'Response | ' + request.name + ' | variables : '+ responseVariable);
			
		} else if(request.name == 'vaildate') {
			
			vaildate(request.variable, function() {
			
				sendResponse({name: 'vaildate', log: 'hello', variable: valid});
				
				console.log(getTime() + 'Response | ' + request.name + ' | variables : '+ valid);
			});
			
			return true;
	
		} else if(request.name == 'options') {
	
			responseLog = 'Fetched options'; 
			responseVariable = options;
			
			// Send Response to popup.js
			sendResponse({name: request.name, log: responseLog, variable: responseVariable});
			
			// Log Response
			console.log(getTime() + 'Response | ' + request.name + ' | variables : '+ responseVariable);
			
		} else if(request.name == 'defaultUserOptions') {
	
			responseLog = 'Fetched default user options'; 
			responseVariable = defaultUserOptions;
				
			// Send Response to popup.js
			sendResponse({name: request.name, log: responseLog, variable: responseVariable});
			
			// Log Response
			console.log(getTime() + 'Response | ' + request.name + ' | variables : '+ responseVariable);
		}

	});
	
	
	// Functions
	function fetchUserOptions(callback) { // Fetch user options 
		
		chrome.storage.sync.get(defaultUserOptions, function(items) {
			userOptions = items; // Pass options to var userOptions;

			callback();			
		});
		
	}
	
	function contextMenus(onStart = false) {  // Create or remove context menus
		/*
			var onStart - true/false - override current userOptions.contextMenuCreated as the extension has been updated or started
		*/
			
		if(onStart == true) {  // Override current userOptions.contextMenuCreated
			
			userOptions.contextMenuCreated = false
			
		}
			
		
		if(userOptions.contextMenuCreated == false && userOptions.contextMenu == true) { // Create 'Archive this' context menu
			
			chrome.contextMenus.create({
				"title": "Archive this page",
				"contexts": ["page"],
				"id": "archive"
			}, function() {
				if (chrome.extension.lastError) {
					console.log(getTime() + "Got expected error: " + chrome.extension.lastError.message);
				}
			});
			
			chrome.storage.sync.set({ // Update contextMenuCreated user option
				contextMenuCreated: true,
			});
			
		} else if(userOptions.contextMenuCreated == true && userOptions.contextMenu == false) { // Remove 'Archive this' context menu
			
			chrome.contextMenus.removeAll(function() {
				if (chrome.extension.lastError) {
					console.log(getTime() + "Got expected error: " + chrome.extension.lastError.message);
				}
			});
			
			chrome.storage.sync.set({ // Update contextMenuCreated user option
				contextMenuCreated: false,
			});
			
		}
		
	}
	
	
	function vaildate(url, callback) { // Vaildate URL and scan robots.txt file
		
		valid = { // Reset Defaults
			url: true,
			disallowMatch: false,
			metaTagFound: false
		}
		
		vaildateUrl(url); // Vaildate URL
		
		if(valid['url'] == true && userOptions.scanRobotsFile == true) { // URL is valid and file scan is enabled
			
			scanRobotsFile(url, callback); // Scan robots.txt for disallow match and run callback 
			
		} else { // URL is not vaild, Run callback
			
			callback();
			
		}
		
	}
	
	function vaildateUrl(url, callback) { // Vaildate Url
		
		var parser = document.createElement('a'); // Get URL parts
		parser.href = url;
		
		console.log(parser.hostname);
		
		var regex = new RegExp(options.regex);
		var regexIPv4 = new RegExp(options.regexIPv4);
		
		// Vaildate URL or an IPv4 address using regular expressions
		if (url.match(regex)) {
	
			// Loop through protocol black list
			for (i = 0; i < options.protocolBlackList.length; i++) {
				if(parser.protocol == options.protocolBlackList[i]) { // Protocol match

					valid['url'] = false;
					break;
				}
			}
		
			// Loop through host name black list
			for (i = 0; i < options.hostNameBlackList.length; i++) {
				if(parser.hostname == options.hostNameBlackList[i]) { // Host Name match

					valid['url'] = false;
					break;
				}
			}

		} else {
			valid['url'] = false;
			console.log(getTime() + 'URL not valid: ' + url);
		}
		
	}
	
	function scanRobotsFile(url, callback) { // Scans each website's robots.txt file to see if a page can be archived.
		
		if(userOptions.scanRobotsFile == true && valid['url'] == true) { // Is enabled and URL is valid 
			
			// Regular expression	
			var disallowLine = new RegExp(/^Disallow:(.*)$/m);
			
			var userAgentMatch = false;
		
			var parser = document.createElement('a'); // Get URL parts
			parser.href = url; 	// https://stackoverflow.com/questions/23913887/javascript-parsing-a-url-into-hostname
				
			var pageRequest = new XMLHttpRequest();
			pageRequest.open('GET', parser.protocol + '//' + parser.hostname + '/robots.txt', true);
				
			pageRequest.onload = function() {
				if (this.status >= 200 && this.status < 400) { // Check HTTP status codes
				
					console.log(getTime() + 'Fetched robots.txt file for ' + parser.hostname);
					console.log(getTime() + 'Starting file scan... ');
				
					var lines = this.response.split('\n');
	
					for(var line = 0; line < lines.length; line++) { // Loop through each line 
						
						lines[line] = lines[line].trim(); // Trim each line
						
						if(lines[line].substring(0, 1) != '#') { // Line is not a comment
						
							// Match wild card user agent
							if (lines[line] == 'User-agent: *' || lines[line] == 'User-Agent: *') {
								console.log('| Match : ' + lines[line]);
							
								userAgentMatch = true;
							
							// Match ia_archiver user agent
							} else if(lines[line] == 'User-Agent: ia_archiver' || lines[line] == 'User-agent: ia_archiver') {
								console.log('| Matched : ' + lines[line]);
							
								userAgentMatch = true;
								
							} else { // Log each disallow  
								console.log('| #' + line + ' "' + lines[line] +'" ');
							}
						
							if(lines[line].length == 0) { // Blank line, Reset userAgentMatch (move this)
							
								userAgentMatch = false;
							
							} else if(userAgentMatch == true) {  // Look for Disallowed matches
						
								matchDisallow = lines[line].match(disallowLine);
								
								if(matchDisallow != null) { // Disallow line found
							
									matchDisallow[1] = matchDisallow[1].substr(1); // Remove space from the front of the string 
									matchDisallowLength = matchDisallow[1].length;
							
									var pathname = parser.pathname.substr(0, matchDisallowLength);
							
									if(pathname === matchDisallow[1]) { // If the parts match 
										console.log('Matched Disallow : '+ matchDisallow[1]);
									
										valid['disallowMatch'] = true;
										break;	
									}
								}
							}
						}
					}

					callback();

				} else { // Server-side error  
					console.log(getTime() + ' robots.txt file not fetched for ' + parser.hostname + ' (Server-side error)');
					
					callback();
				}
			};

			pageRequest.onerror = function() { // Connection error
				console.log(getTime() + ' robots.txt file not fetched for ' + parser.hostname + ' (Connection error)');
				
				callback();
			};

			pageRequest.send();
		
		} else if(userOptions.scanRobotsFile == false && useCallback == true) { // Not enbaled, Send default back.
			
			log = 'Function '+ request.name +'() not nun, Option not enbaled.'; 

			callback({name: request.name, log: log, variable: false});
			
			// Log Response
			console.log(getTime() + 'Response | ' + request.name + ' | variables : false');
		}
		
	}
	
	
	function openTab(url) { // Create new tab
		
		if(valid['url'] == true && valid['disallowMatch'] == false) {
			
			chrome.tabs.create({ url: options.saveUrl + url }); 	
			
		}
		
	}
	
	function notifyUser(url) { // Show notification if URL is not vaild (Right click menu only)
		
		if(userOptions.contextMenuNote == true) { // Is enabled
			
			var id = getRandomId();
			
			var noteInfo = {
				title: 'This page can not be archived, Sorry!',
				iconUrl: '/images/128.png',
				type: 'basic',
				message: ''
			}  
			
			if(valid['url'] == false && valid['disallowMatch'] == false) { // URL not valid 
				
				noteInfo['message'] = 'The Wayback Machine can not archive local files or pages from web.archive.org.';
	
			} else if(valid['url'] == true && valid['disallowMatch'] == true) { // Disallow match
				
				noteInfo['message'] = "Request blocked by the website's robots.txt file.";
				
			}
			
			// Create notification
			chrome.notifications.create(id, noteInfo);
			
			// Log
			console.log(getTime() + "Created notification '"+ noteInfo['message'] +"' ");
		}	
	}
	
	function notifyUserSound() { // Plays alert along the notification, if enabled. 
		
		if(userOptions.notePlayAlert == true) {
			
			var sound = userOptions.noteAlertSound;
			
			if(typeof options.alertSounds[sound] != 'undefined') {
			
				var file = options.alertSounds[sound];		
				var audio = new Audio('sounds/' + file);
				audio.play();	
				
				console.log(getTime() + "Played notification sound (#" + sound + ") ");
			}
		}
		
	}
	
	function getRandomId() { // Creates a somewhat random ID
		
		var id = Math.floor(Math.random() * 9007199254740992) + 1;
		return id.toString();
	}
		
	function logNumber() { // Logs number
	
		chrome.storage.sync.get({
			pagesArchived: 0, // Default
		}, function(items) {
			items.pagesArchived++;
			
			chrome.storage.sync.set({'pagesArchived': items.pagesArchived}, function() {
				console.log(getTime() + 'number updated');
			});
		});
		
	} 
		
	function getTime() { // Returns current time (for console.log only)
		
		var time = new Date();
		
		return ("0" + time.getHours()).slice(-2)   + ":" + 
			("0" + time.getMinutes()).slice(-2) + ":" + 
			("0" + time.getSeconds()).slice(-2) + " | ";
	}
	