
	// Hard coded options
	var valid = {}
	var saved = {}
	
	var options = {
		regex: /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,20}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi,
		regexIPv4: /^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/,
		protocolBlackList: ['chrome:','chrome-extension:','ftp:','file:','view-source:'],
		hostNameBlackList: ['web.archive.org','127.0.0.1'],
		saveUrl: "https://web.archive.org/save/",
		calendarUrl: "https://web.archive.org/web/*/",
		apiUrl: "https://archive.org/wayback/available?url=",
		alertSounds: ['served-alert.mp3','job-done.mp3']
	}
	
	// Default User Options date
	var defaultDate = new Date();
	defaultDate.setHours(0);
	defaultDate.setMinutes(0);
	defaultDate.setSeconds(0);
	defaultDate.setMilliseconds(0);
	
	//console.log(defaultDate);
	
	var defaultUserOptions = {
		
		// Page Archived and number format
		numberFormat: '1,000', // Format to display numbers
		//archived: 0, // Total number of pages archived  
		//archivedToday: 0, // Number of pages archived today 
		//archivedYesterday: 0, // Number of pages archived yesterday
		
		archivedDate: defaultDate.getTime(), // Current date at install
		
		consoleLog: false, // Log actions in the browser's dev console
		
		logNumberArchived: true, // Log number of pages archived
		
		// Date and time formats
		dateFormat: 'F j, Y',
		timeFormat: 'g:i A',
		timeZoneConvert: true,
		
		// Context Menus
		contextMenu: true, // Show 'Archive this' link is the context menu
		contextMenuNote: true, // Display note if a page cannot be archived via the context menu
		
		// Notifications
		notePlayAlert: false, // Play alert sound when a notification is displayed.
		noteAlertSound: 0, // Default Alert sound.
		
		// Scan robots.txt file
		scanRobotsFile: false, // Scan each website's robots.txt file 
		archiveAnyway: false, // Show 'archive anyway' button if request is blocked by robots.txt .
		
		// Tab free page saving
		tabFreeArchiving: false, // Saving page to the wayback machine without opening a new tab
	}
	
	// User options from chrome.storage
	var userOptions = {};

	var contextMenuSet = false;
	
	fetchUserOptions(function() { // Fetch user options
		contextMenus();
	});
	
	// Listener for then the extension is installed or updated
	chrome.runtime.onInstalled.addListener(function(details) {
    
		if(details.reason == "install") {
			console.log(getTime() + "This is a first install!");
			
		} else if(details.reason == "update") {
			var thisVersion = chrome.runtime.getManifest().version;
			
			console.log(getTime() + "Updated from " + details.previousVersion + " to " + thisVersion + "!");			
		}
	});
	
	// Listener for then the extension is started
	chrome.runtime.onStartup.addListener(function() {});
	
	// Listener for then the storage has changed
	chrome.storage.onChanged.addListener(function(changes, namespace) {

		fetchUserOptions(function() { // Fetch user options and run contextMenus() function
			contextMenus();
		});

	});
	
	// Listener for on click of the context menu link
	chrome.contextMenus.onClicked.addListener(function(info, tab) {
		//console.log(info);
		
		vaildate(tab.url, function() {
			
			if(valid['url'] == true && valid['disallowMatch'] == false) { // URL is vaild, log number 

				logNumber();
				openTab(tab.url); // Open save URL

			} else { // Show Notification
			
				notifyUser(tab.url); // Show notification
				notifyUserSound(); // Play sound, if enabled
			
			}
			
		});		
	});
	
	// Message listener for messages from pop.js
	chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
		var responseLog;
		var responseVariable;
		
		// Log request
		consoleLog('Request | ' + request.name + ' | variables : '+ request.variable);
			
		if(request.name == 'logNumber') { // Log number(s)

			logNumber();
			responseVariable = valid['url'];	
			
			sendResponse({name: 'logNumber', variable: valid});
			
			// Log Response
			consoleLog('Response | ' + request.name + ' | variables : '+ responseVariable);
			
		} else if(request.name == 'vaildate') { // Vaildate page URL or IPv4
			
			vaildate(request.variable, function() {
			
				sendResponse({name: 'vaildate', variable: valid});	
				consoleLog('Response | ' + request.name + ' | variables : '+ valid);

			});
			
			return true;
	
		} else if(request.name == 'saveByAjax') { // save URL by ajax GET request
			
			saveByAjax(request.variable, function() {
			
				sendResponse({name: 'saveByAjax', variable: saved});
				consoleLog('Response | ' + request.name + ' | variables : '+ saved);
				
				if(saved['saved'] == true) { // log number if page was saved 

					logNumber();

				}

			});
			
			
			return true;
	
		} else if(request.name == 'options') { // All Options (options, userOptions and defaultUserOptions)

			responseVariable = {options: options, userOptions: userOptions, defaultUserOptions: defaultUserOptions}
			
			// Send Response to popup.js
			sendResponse({name: request.name, variable: responseVariable});
			
			// Log Response
			consoleLog('Response | ' + request.name + ' | variables : '+ responseVariable);
			
		}

	});
	
	
	// Functions
	function fetchUserOptions(callback) { // Fetch user options 
		
		chrome.storage.sync.get(defaultUserOptions, function(items) {
			userOptions = items; // Pass options to var userOptions;
	
			callback();			
		});
		
	}
	
	function contextMenus() {  // Create or remove context menus

		if(contextMenuSet == false && userOptions.contextMenu == true) { // Create 'Archive this' context menu

			chrome.contextMenus.create({
				"title": "Archive this page",
				"contexts": ["page"],
				"id": "archivePage"
			}, function() {
				if (chrome.extension.lastError) {
					consoleLog("Got expected error: " + chrome.extension.lastError.message);
				}
			});
			
			contextMenuSet = true;
			
		} else if(contextMenuSet == true && userOptions.contextMenu == false) { // Remove 'Archive this' context menu
			
			chrome.contextMenus.removeAll(function() {
				if (chrome.extension.lastError) {
					consoleLog("Got expected error: " + chrome.extension.lastError.message);
				}
			});
			
			contextMenuSet = false;
			
		}
		
	}
	
	
	function vaildate(url, callback) { // Vaildate URL and scan robots.txt file
		
		valid = { // Defaults
			url: true, // URL is vaild
			disallowMatch: false, // Robots.txt disallow match
			metaTagFound: false
		}
		
		vaildateUrl(url); // Vaildate URL
		
		if(valid['url'] == true && userOptions.scanRobotsFile == true) { // URL is valid and file scan is enabled
			
			scanRobotsFile(url, callback); // Scan robots.txt for disallow match and run callback 
			
		} else { // URL is not vaild, Run callback
			
			callback();
			
		}
		
	}
	
	function vaildateUrl(url, callback) { // Vaildate Url
		
		var parser = document.createElement('a'); // Get URL parts
		parser.href = url;
		
		var regex = new RegExp(options.regex);
		var regexIPv4 = new RegExp(options.regexIPv4);
		
		// Vaildate URL or an IPv4 address using regular expressions
		if (url.match(regex) || url.match(parser.hostname)) {
	
			// Loop through protocol black list
			for (i = 0; i < options.protocolBlackList.length; i++) {
				if(parser.protocol == options.protocolBlackList[i]) { // Protocol match

					valid['url'] = false;
					break;
				}
			}
		
			// Loop through host name black list
			for (i = 0; i < options.hostNameBlackList.length; i++) {
				if(parser.hostname == options.hostNameBlackList[i]) { // Host Name match

					valid['url'] = false;
					break;
				}
			}

		} else {
			valid['url'] = false;
			consoleLog('URL not valid: ' + url);
		}
		
	}
	
	function scanRobotsFile(url, callback) { // Scans each website's robots.txt file to see if a page can be archived.
		
		if(userOptions.scanRobotsFile == true && valid['url'] == true) { // Is enabled and URL is valid 
			
			// Regular expression	
			var disallowLine = new RegExp(/^Disallow:(.*)$/m);
			var userAgentLine = new RegExp(/^User-Agent: (.*)$/mi);
			
			var userAgentMatch = false;
		
			var parser = document.createElement('a'); // Get URL parts
			parser.href = url; 	// https://stackoverflow.com/questions/23913887/javascript-parsing-a-url-into-hostname
				
			var pageRequest = new XMLHttpRequest();
			pageRequest.open('GET', parser.protocol + '//' + parser.hostname + '/robots.txt', true);
				
			pageRequest.onload = function() {
				if (this.status >= 200 && this.status < 400) { // Check HTTP status code
				
					consoleLog('Fetched robots.txt file for ' + parser.hostname);
					consoleLog('Starting file scan...');
				
					var lines = this.response.split('\n');
	
					for(var line = 0; line < lines.length; line++) { // Loop through each line 
						
						lines[line] = lines[line].trim(); // Trim each line
						
						if(lines[line].length == 0) { // Blank line, Reset userAgentMatch to false 
	
							consoleLog('| #' + line + ' blank ', false);
							userAgentMatch = false;
	
						} else if(lines[line].substring(0, 1) == '#') { // Comment line, Reset userAgentMatch to false 
	
							consoleLog('| #' + line + ' Comment ', false);
							//userAgentMatch = false;
	
						} else if(agentMatch = lines[line].match(userAgentLine)) { // User agent
							
							if(agentMatch[1] == '*' || agentMatch[1] == 'ia_archiver') { // Match user agent
							
								consoleLog('| Match : ' + lines[line], false);
								userAgentMatch = true;							
								
							} else { // User agent not match 
								
								consoleLog('| Not Matched : ' + lines[line], false);
								userAgentMatch = false;	
								
							}	
						} else {
	
							consoleLog('| #' + line + ' "' + lines[line] +'" ', false);
							
						}
	
						if(userAgentMatch == true) {
						
							// Look for Disallowed matches
							matchDisallow = lines[line].match(disallowLine);
	
							if(matchDisallow != null) { // Disallow line found
							
								matchDisallow[1] = matchDisallow[1].substr(1); // Remove space from the front of the string 
								matchDisallowLength = matchDisallow[1].length;
							
								var pathname = parser.pathname.substr(0, matchDisallowLength);
									
								if(matchDisallow[1] === '') { // User agent allow to crawl whole website  

									valid['disallowMatch'] = false;
									break;	
	
								} else if(pathname === matchDisallow[1]) { // User agent not allow to crawl current URL 
									consoleLog('Matched Disallow : '+ matchDisallow[1], false);
									
									valid['disallowMatch'] = true;
									break;	
								}
							}
						}
					}

					callback();

				} else { // Server-side error  
					
					consoleLog(' robots.txt file not fetched for ' + parser.hostname + ' (Server-side error)');	
					callback();
				}
			};

			pageRequest.onerror = function() { // Connection error
				
				consoleLog(' robots.txt file not fetched for ' + parser.hostname + ' (Connection error)');
				callback();
				
			};

			pageRequest.send();
		
		}
		
	}
	
	function saveByAjax(url, callback) { // Save by ajax to the save URL

		saved = {
			saved: false,
			pageLocation: '',
			error: '',	
			errorCode: 200,
		}
	
		var request = new XMLHttpRequest();
		request.open('GET', options.saveUrl + url, true);
		//request.open('GET', 'https://http418.verifiedjoseph.com/500', true);
	
		request.onload = function() {
				
			//var runtimeError = [];
			//runtimeError[0] = 'LiveDocumentNotAvailableException';
			
			if (this.status == 200) { // Check HTTP status codes
	
				archivedLocation = request.getResponseHeader('Content-Location');
	
				if(archivedLocation != null) {

					saved['saved'] = true;
					saved['pageLocation'] = archivedLocation;

				}
	
			} else { // Client and Server-side errors
				
				var runtimeError = request.getResponseHeader('X-Archive-Wayback-Runtime-Error').split(':');
				
				//console.log(this.status);
				//console.log(request.getResponseHeader('X-Archive-Wayback-Runtime-Error'));
	
				saved['saved'] = false;
				saved['errorCode'] = this.status;

				if(runtimeError[0] == 'AdministrativeAccessControlException') { // Black listed website
	
					saved['error'] = 'Website has been excluded from the Wayback Machine.';
					
				} else if(runtimeError[0] == 'RobotAccessControlException') { // Blocked By robots.txt file

					saved['error'] = 'Request blocked by robots.txt file.';
	
				} else if(runtimeError[0] == 'LiveDocumentNotAvailableException') { // IA faild to fetch page
				
					saved['error'] = 'Wayback Machine was unable to fetch the page.<BR/><BR/> Try agian later.'
				
				} else { // Unkown Error
					
					saved['error'] = 'An unkown error occurred.';

				}
			}
			
			callback();
			
		};

		request.onerror = function() { // Connection error
		
			saved['saved'] = false;
			saved['errorCode'] = this.status;
			saved['error'] = 'An unkown error occurred.';

			callback();
			
		};

		request.send();

		
	}
	
	
	function openTab(url) { // Create new tab
		
		if(valid['url'] == true && valid['disallowMatch'] == false) {
			
			chrome.tabs.create({ url: options.saveUrl + url }); 	
			
		}
		
	}
	
	function notifyUser(url) { // Show notification if URL is not vaild (Right click menu only)
		
		if(userOptions.contextMenuNote == true) { // Is enabled
			
			var id = getRandomId();
			
			var noteInfo = {
				title: 'This page can not be archived, Sorry!',
				iconUrl: '/images/128.png',
				type: 'basic',
				message: ''
			} 
			
			if(valid['url'] == false && valid['disallowMatch'] == false) { // URL not valid 
				
				noteInfo['message'] = 'The Wayback Machine can not archive local files or pages from web.archive.org.';
	
			} else if(valid['url'] == true && valid['disallowMatch'] == true) { // Disallow match
				
				noteInfo['message'] = "Request blocked by the website's robots.txt file.";
				
			}
			
			// Create notification
			chrome.notifications.create(id, noteInfo);
			
			// Log
			consoleLog("Created notification '"+ noteInfo['message'] +"' ");
		}	
	}
	
	function notifyUserSound() { // Plays alert along the notification, if enabled. 
		
		if(userOptions.notePlayAlert == true) {
			
			var sound = userOptions.noteAlertSound;
			
			if(typeof options.alertSounds[sound] != 'undefined') {
			
				var file = options.alertSounds[sound];		
				var audio = new Audio('sounds/' + file);
				audio.play();	
				
				consoleLog("Played notification sound (#" + sound + ") ");
			}
		}
		
	}
	
	function getRandomId() { // Creates a somewhat random ID (not cryptographically secure)
		
		var id = Math.floor(Math.random() * 9007199254740992) + 1;
		return id.toString();
		
	}
		
	function logNumber() { // Logs number
		
		chrome.storage.sync.get({
			// Defaults
			pagesArchived: 0,
			archivedToday: 0,
			archivedYesterday: 0,
		}, function(items) {
			items.pagesArchived++;
			
			var oneDay = 60*60*24*1000; // 1 day in milliseconds
		
			var dateNow = new Date(); // Time and date now 
			dateNow.setHours(0);
			dateNow.setMinutes(0);
			dateNow.setSeconds(0);
			dateNow.setMilliseconds(0);
			
			var storedDate = new Date(userOptions.archivedDate);
		
			daysPassed = Math.floor((dateNow - storedDate) / oneDay); // Number of days passed 
		
			consoleLog(dateNow + ' ' + storedDate);
			consoleLog(daysPassed + ' full days between');
		
			if(daysPassed > 0) { // If a day(s) has passed, shift today & yesterday numbers 
				
				if(daysPassed > 1) { // If more that one day has passed 

					items.archivedYesterday = 0; // Yesterday
					items.archivedToday = 1; // Today
					
				} else { // Only one day has passed
					
					items.archivedYesterday = items.archivedToday // Yesterday
					items.archivedToday = 1; // Today
					
				}
	
				chrome.storage.sync.set({
					'archivedDate': dateNow.getTime(),
					'pagesArchived': items.pagesArchived, 
					'archivedToday': items.archivedToday, 
					'archivedYesterday': items.archivedYesterday
				}, function() {
					consoleLog('Numbers and archivedDate updated');
				});
				
			} else { // Same day, update Today and pagesArchived totals only.
				
				items.archivedToday++;
				
				chrome.storage.sync.set({
					'pagesArchived': items.pagesArchived,
					'archivedToday': items.archivedToday
				}, function() {
					consoleLog('Numbers updated');
				});
				
			}
			
		});
		
	} 
		
	function getTime() { // Returns current time (for console.log only)
		
		var time = new Date();

		return ("0" + time.getHours()).slice(-2)   + ":" + 
			("0" + time.getMinutes()).slice(-2) + ":" + 
			("0" + time.getSeconds()).slice(-2) + " | ";
	}
	
	function consoleLog(text, showTime = true) { // Log text and time with console.log
		
		if(userOptions.consoleLog == true) {

			if(showTime == true) {
			
				console.log(getTime() + text);
			
			} else {

				console.log(text);		
		
			}		
			
		}
	
	}