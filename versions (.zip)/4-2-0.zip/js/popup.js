window.onload = function() {
	//chrome.browserAction.setBadgeText({text:""});
	var currentUrl;
	var archivedVersion; // Archived version url returned in the web archive API. 
	var archivedLocation; // Archived Location (saving with ajax)
	var valid = {};
	var saved = {};
	
	var options = {}; // Hard coded options
	var userOptions = {}; // User options
	
	chrome.tabs.query({currentWindow: true, active: true}, function(tabs) { // Current tab URL	
	
		currentUrl = tabs[0].url;
		background('options', false, start); // Fetch hard coded options and user options from the background page and start the main script
		
	});
	
	// Event listener for opening options page
	document.getElementById('options').addEventListener('click', function() {
		
		window.open(chrome.runtime.getURL('options_tab.html'));

	});
	
	// Event listener for opening stats view
	document.getElementById('stats').addEventListener('click', function() {

		display('stats-view','block');
		display('options-box','none');
		
		fetchNumber();
		
	});
	
	// Event listener for closing stats view (back)
	document.getElementById('back').addEventListener('click', function() {
		
		display('stats-view','none');
		display('options-box','block');
		
	});
	
	// Event listener for resetting stats number
	document.getElementById('reset-number').addEventListener('click', function() {
		
		if(confirm("Are you sure you?")) {
			
			resetNumber();
		
		}
	});
	
	// Event listener for archive now button
	document.getElementById('archive-now').addEventListener('click', function() {
		
		if(userOptions.tabFreeArchiving == true) { // Achive page by XMLHttpRequest , if enabled
			
			background('saveByAjax', currentUrl, wasSaved);
			
			display('archiving','block'); // Show archiving div
			
		} else { // Achive page by open save URL in a tab 
		
			chrome.runtime.sendMessage({name: 'logNumber'}, function(response) {

				openTab(options.saveUrl); //  Open tab

			});
		
		}
	});
	
	
	function start(allOptions) { // Start 

		options = allOptions.options;
		userOptions = allOptions.userOptions;
		
		//console.log(allOptions);
		
		background('vaildate', currentUrl, isValid); // Vaildate current Tab URL	

	}
	
	function background(name, variable, callback) { // Sends a message to background.js to run a function.
		
		chrome.runtime.sendMessage({name: name, variable: variable}, function(response) {
		
			if(name == 'options') { // Pass options to the callback function
				
				//console.log(getTime() + 'Options fetched from background.js');
				callback(response.variable);
				
			} else { // Pass whole response to the callback function
				callback(response);
			}
			
		});	
		
	}
	
	
	function isValid(response) { // Check If background funtions found the URL valid
		
		valid = response.variable;
		
		var errorDiv = document.getElementById('error');
		
		if(valid['url'] == true && valid['disallowMatch'] == false) { // Valid URL and not blocked by robots.txt 
			
			consoleLog('URL: ' + currentUrl + ' is valid');
			
			fetchData(); // Fetch API data
			
		} else if(valid['disallowMatch'] == true) { // robots.txt Disallow match
			
			if(valid['url'] == true) {
			
				consoleLog('URL: ' + currentUrl + ' is valid');
			
			}
			
			consoleLog('Request blocked by robots.txt file.');
			errorDiv.querySelector('#reason').innerHTML = 'Request blocked by robots.txt file.';  // Update reason
	
			display('loading','none'); // Hide loading text
			display('error','block'); // Show error box
			
			if(userOptions.archiveAnyway == true) {
				
				display('archive-anyway','block'); // Show archive anyway button
				
				// Set button click event listener for archive anyway button
				document.getElementById('archive-anyway').addEventListener('click', function() {
					
					if(userOptions.tabFreeArchiving == true) { // Achive page by XMLHttpRequest , if enabled
			
						background('saveByAjax', currentUrl, wasSaved);
						
						display('error','none'); // Hide error div
						display('archive-anyway','none'); // Hide archive anyway button div
						display('archiving','block'); // Show archiving div
			
					} else { // Achive page by open save URL in a tab 
		
						openTab(options.saveUrl, true); //  Open tab, overriding valid['disallowMatch']  
						
					}
				});
			}
			
		} else { // URL not valid
			
			consoleLog('URL: ' + currentUrl + ' is not valid');
			errorDiv.querySelector('#reason').innerHTML = 'URL or IP address is not valid';  // Update reason
			
			display('loading','none'); // Hide loading text
			display('error','block'); // Show error box
			
		}
		
	}
		
	function wasSaved(response) { // Check If background funtions saved the page 
		
		saved = response.variable;
		
		var archivingDiv = document.getElementById('archiving');
		
		display('loading-an','none'); // Hide archiving loading div
		
		if(saved['errorCode'] != '200') { // Error 
		
			archivingDiv.querySelector('#title').innerHTML = "Page Not Archived";
			archivingDiv.querySelector('#reason').innerHTML = saved['error'];
			
		} else { // Page saved

			archivedLocation = saved['pageLocation'];

			archivingDiv.querySelector('#title').innerHTML = "Page Archived";

			display('archive-version-e','block'); // Show button

			//Add event listener for button
			document.getElementById('archive-version-e').addEventListener('click', function() {

				archivedVersionUrl = 'https://web.archive.org' + archivedLocation;
				chrome.tabs.create({ url: archivedVersionUrl});

			});

		}
		
		
	}
		
	function fetchData() { // Fetch data about current page from the Wayback Machine API
		
		var request = new XMLHttpRequest();
		request.open('GET', options.apiUrl + currentUrl, true);

		request.onload = function() {
			if (this.status >= 200 && this.status < 400) { // Check HTTP status codes
			
				var data = JSON.parse(this.response);
			
				consoleLog('API Data fetched for ' + currentUrl);
				consoleLog(data, false);
	
				// If the API has returned a snapshot
				if(data['archived_snapshots'].hasOwnProperty('closest')) {
					display('loading','none'); // Hide loading text

					archivedVersion = data['archived_snapshots']['closest']['url'];
				
					var timeDate = data['archived_snapshots']['closest']['timestamp'];
					
					updateHTML('date', formatTimeDate('date',timeDate)); // Date
					updateHTML('time', formatTimeDate('time',timeDate)); // Time
				
					display('time-date','block'); // Show time and date
				
					// Event listener for arhcive history button
					document.getElementById('archive-history').addEventListener('click', function() {
						openTab(options.calendarUrl);
					});
				
					// Event listener for archive version button
					document.getElementById('archive-version').addEventListener('click', function() {
						chrome.tabs.create({ url: archivedVersion}); 
					});
				
				} else { // Snapshot not returned

					display('loading','none'); // Hide loading text
					display('api-error-one','block');

					display('archive-version','none');
					display('archive-history','none');

					//document.getElementById('details').style.height = '56px';
				}
			
			} else { // Server-side error  
				consoleLog(getTime() + 'API Data not fetched for ' + currentUrl);
			
				display('loading','none'); // Hide loading text
				display('api-error-two','block');

				display('archive-version','none');
				display('archive-history','none');
			}
		};

		request.onerror = function() { // Connection error
			consoleLog(getTime() + 'API Data not fetched for ' + currentUrl);
			
			display('loading','none'); // Hide loading text
			display('api-error-two','block');

			display('archive-version','none');
			display('archive-history','none');
		};

		request.send();
	}
		
	function openTab(type, override = false) { // Open archive save URL or history list URL in a new tab 
		/*
			var type - type of url to open
			var override - Override valid['disallowMatch'] and open save tab 
		*/
		
		if(valid['url'] == true && valid['disallowMatch'] == false || valid['url'] == true && override == true) {
	
			consoleLog(getTime() + 'Opening URL : ' + currentUrl + ' | type ' + type);
			chrome.tabs.create({ url: type + currentUrl });
			
		}
	
	}
	
	function formatTimeDate(type = 'date', timeDate) { // Formats the time and date stamp return by the Wayback API
		/*
			var type - Return date or time for a timestamp
			var timeDate - date time string 
		*/
		
		var output;
		var months = {'1': "January", '2': "February", '3': "March", '4': "April", '5': "May", '6': "June", '7': "July", '8': "August", '9': "September", '10': "October", '11': "November", '12': "December"};
		
		// Time stamp parts
		var year = timeDate.substr(0, 4);
		var month = timeDate.substr(4, 2);
		var day = timeDate.substr(6, 2);
		
		var hour = timeDate.substr(8, 2);
		var min = timeDate.substr(10, 2);
		var sec = timeDate.substr(12, 2);

		
		if(userOptions.timeZoneConvert == true) { // Convert to local timezone
			
			var UTC = month + '/'+ day +'/'+ year + ' ' + hour + ':' + min + ':'+ sec +' UTC';
			var UTCtime = new Date(UTC);
			UTCtime.toLocaleString();
			
			// Local Time stamp parts
			var localTime = new Date(UTCtime);
			
			year = localTime.getFullYear();
			month = localTime.getMonth() + 1;
			day = localTime.getDate();
			
			hour = localTime.getHours();
			min = localTime.getMinutes();
			sec = localTime.getSeconds();

		}
		
		if (typeof timeDate != 'undefined') {
			
			if (type == 'date') {
				
				if(userOptions.dateFormat == 'F j, Y') { // F j, Y - June 5, 2016

					if(day < 10 && userOptions.timeZoneConvert == false) { // Removed zero when not using a convert time stamp
						day = day.substr(1);
					}

					if(month < 10 && userOptions.timeZoneConvert == false) { // Removed zero when not using a convert time stamp
						month = month.substr(1);
					}
					
					output = months[month] + ' ' + day + ', ' + year;
				
				} else if(userOptions.dateFormat == 'Y/m/d') { // Y/m/d - 2016/06/05
					
					output = year + '/' + month + '/' + day;
					
				} else if (userOptions.dateFormat == 'd/m/Y') { // d/m/Y - 05/06/2016
					
					output = day + '/' + month + '/' + year;	
	
				} else if (userOptions.dateFormat == 'm/d/Y') { // m/d/Y - 06/05/2016
					
					output = month + '/' + day + '/' + year;						
					
				}
				
			} else if(type == 'time') {

				var ap = 'AM';

				if(userOptions.timeFormat == 'g:i A' || 'g:i:s A') { // g:i A - 02:50 (PM/AM) & g:i:s A - 02:50:48 (PM/AM)
					
					if (hour > 12) {
						
						hour -= 12;
						ap = "PM";
						
						if(userOptions.timeZoneConvert == true) { // Add zero when using a convert time stamp
					
							if(hour < 10) {
								hour = '0' + hour;
							}

							if(min < 10) {
								min = '0' + min;
							}
						}
						
					} else if (hour === 0) {
						
						hour = 12;
					
					}
				
					if(userOptions.timeFormat == 'g:i A') {
						
						output = hour + ':' + min + ' ' + ap;
						
					} else { // With seconds
						
						output = hour + ':' + min + ':' + sec + ' ' + ap;
						
					}
					
				} else if (userOptions.timeFormat == 'H:i') { // H:i - 14:50
					
					output = hour + ':' + min;
					
				} else if(userOptions.timeFormat == 'H:i:s') { // H:i:s - 14:50:48
	
					output = hour + ':' + min + ':' + sec;	
					
				}
			}
			
			return output;
		
		}	
		
	}
	
	function fetchNumber() { // Fetch number of pages archived by the user
		
		chrome.storage.sync.get({
			// Defaults
			pagesArchived: 0,
			archivedToday: 0,
			archivedYesterday: 0,
		}, function(items) {
		
			var oneDay = 60*60*24*1000; // 1 day in milliseconds
		
			var dateNow = new Date(); // Time and date now 
			dateNow.setHours(0);
			dateNow.setMinutes(0);
			dateNow.setSeconds(0);
			dateNow.setMilliseconds(0);
			
			var storedDate = new Date(userOptions.archivedDate);
		
			daysPassed = Math.floor((dateNow - storedDate) / oneDay); // Number of days passed 
		
			consoleLog(dateNow + ' ' + storedDate);
			consoleLog(daysPassed + ' full days between');
		
			if(daysPassed > 0) { // If a day(s) has passed, shift today & yesterday numbers 
				
				if(daysPassed > 1) { // If more that one day has passed 
					
					items.archivedYesterday = 0; // Yesterday
					items.archivedToday = 0; // Today
					
				} else { // Only one day has passed
					
					items.archivedYesterday = items.archivedToday; // Yesterday
					items.archivedToday = 0; // Today	
					
				}
				
	
				chrome.storage.sync.set({
					'archivedDate': dateNow.getTime(),
					'pagesArchived': items.pagesArchived, 
					'archivedToday': items.archivedToday, 
					'archivedYesterday': items.archivedYesterday
				}, function() {
					consoleLog('Numbers and archivedDate updated');
				});
				
			}
		
			// Display numbers
			updateHTML('total-number', formatNumber(items.pagesArchived));			
			updateHTML('number-today', formatNumber(items.archivedToday));
			updateHTML('number-yesterday', formatNumber(items.archivedYesterday));

		});
		
	}
	
	function resetNumber() { // Reset pages archived numbers
		
		chrome.storage.sync.set({
			'pagesArchived': 0, 
			'archivedToday': 0, 
			'archivedYesterday': 0
		}, function() {

			updateHTML('total-number',0);
			updateHTML('number-today',0);
			updateHTML('number-yesterday',0);
			
			consoleLog('Archived numbers reset to 0');
		});
		
	}
	
	function formatNumber(n) { // Format numbers to user set format
		
		var regex = /(\d+)(\d{3})/;
		var format;
		
		if(userOptions.numberFormat == '1,000') {
			
			format = ',';
			
		} else if(userOptions.numberFormat == '1 000') {
		
			format = ' ';		
			
		} else if(userOptions.numberFormat == '1.000') {
			
			format = '.';
			
		}
		
		if(n >= 1000) {	
			n = n.toString();
	
			while (regex.test(n)) {
				n = n.replace(regex, '$1' + format + '$2');	
			}
			
		}
		
		return n;
		
	}
		
	function display(element, display = 'none') { // Change visibility of a html element
		
		if (typeof element != 'undefined') {
			document.getElementById(element).style.display = display;
		}
		
	}
	
	function updateHTML(element, data = '') { // Update the inner html/text of a html element
		
		if (typeof element != 'undefined') {
			document.getElementById(element).innerHTML = data;
		}
		
	}
	
	function getTime() { // Returns current time (for console.log only)
		
		var time = new Date();
		
		return ("0" + time.getHours()).slice(-2)   + ":" + 
			("0" + time.getMinutes()).slice(-2) + ":" + 
			("0" + time.getSeconds()).slice(-2) + " | ";
	}
	
	function consoleLog(text, showTime = true) { // Log text and time with console.log
		
		if(userOptions.consoleLog == true) {

			if(showTime == true) {
			
				console.log(getTime() + text);
			
			} else {

				console.log(text);		
		
			}
		}
	
	}
	
}