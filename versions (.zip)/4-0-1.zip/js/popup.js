window.onload = function() {
	//chrome.browserAction.setBadgeText({text:"DR"});
	
	var currentUrl;
	var archivedVersion; // Archived version url returned in the web archive API. 
	var valid = {};
	
	var options = {}; // Hard coded options
	var userOptions = {}; // User options
	
	chrome.tabs.query({currentWindow: true, active: true}, function(tabs) { // Current tab URL	
		currentUrl = tabs[0].url;
		
		background('options', false, start); // Fetch options from the background page and start the main script
	});
	
	// Event listener for opening options page
	document.getElementById('options').addEventListener('click', function() {
		
		window.open(chrome.runtime.getURL('options_tab.html'));
		
		/*if (chrome.runtime.openOptionsPage) { // New way to open options pages, if supported (Chrome 42+).

			chrome.runtime.openOptionsPage();
		} else {
			window.open(chrome.runtime.getURL('options_tab.html')); // Reasonable fallback. (Chrome 41 or older)
		}*/
	});
	
	// Event listener for opening stats view
	document.getElementById('stats').addEventListener('click', function() {
		display('stats-view','block');
		display('options-box','none');
		
		fetchNumber();
	});
	
	// Event listener for closing stats view (back)
	document.getElementById('back').addEventListener('click', function() {
		display('stats-view','none');
		display('options-box','block');
	});
	
	// Event listener for resetting stats number
	document.getElementById('reset-number').addEventListener('click', function() {
		if(confirm("Are you sure you?")) {
			resetNumber();
		}
	});
	
	// Event listener for arhcive now button
	document.getElementById('archive-now').addEventListener('click', function() {
		chrome.runtime.sendMessage({name: 'logNumber'}, function(response) {

			openTab(options.saveUrl); //  Open tab

		});
	});
	
	
	function start(bgOptions) { // Start 

		options = bgOptions;

		background('vaildate', currentUrl, isValid); // Vaildate current Tab URL	

	}
	
	function background(name, variable, callback) { // Sends a message to background.js to run a function.
		
		chrome.runtime.sendMessage({name: name, variable: variable}, function(response) {

			if(name == 'options') { // Pass options to the callback function
			
				console.log(getTime() + 'Options fetched from background.js');
				callback(response.variable);
				
			} else { // Pass whole response to the callback function
				callback(response);
			}
		});	
		
	}
	
	
	function isValid(response) { // Check If background funtions found the URL valid
		
		valid = response.variable;
		
		if(valid['url'] == true && valid['disallowMatch'] == false) { // Valid URL and not blocked by robots.txt 
			
			console.log(getTime() + 'URL: ' + currentUrl + ' is valid');
			
			fetchData(); // Fetch API data
			
		} else if(valid['disallowMatch'] == true) { // robots.txt Disallow match
			
			console.log(getTime() + 'Request blocked by robots.txt file.');
			
			document.getElementById("reason").innerHTML = 'Request blocked by robots.txt file.';  // Update reason 
			
			display('loading','none'); // Hide loading text
			display('error','block'); // Show error box
			
		} else { // URL not valid
			
			console.log(getTime() + 'URL: ' + currentUrl + ' is not valid');
			
			document.getElementById("reason").innerHTML = '';  // Update reason 
			
			display('loading','none'); // Hide loading text
			display('error','block'); // Show error box
			
		}
		
	}
		
	function fetchData() { // Fetch data about current page from the Wayback Machine API
		
		var request = new XMLHttpRequest();
		request.open('GET', options.apiUrl + currentUrl, true);

		request.onload = function() {
			if (this.status >= 200 && this.status < 400) { // Check HTTP status codes
			
				var data = JSON.parse(this.response);
			
				console.log(getTime() + 'API Data fetched for ' + currentUrl);
				console.log(data);
	
				// If the API has returned a snapshot
				if(data['archived_snapshots'].hasOwnProperty('closest')) {
					display('loading','none'); // Hide loading text

					archivedVersion = data['archived_snapshots']['closest']['url'];
				
					var timeDate = data['archived_snapshots']['closest']['timestamp'];
				
					document.getElementById("date").innerHTML = formatTimeDate('date',timeDate); // Date
					document.getElementById("time").innerHTML = formatTimeDate('time',timeDate); // Time 
				
					display('time-date','block'); // Show time and date
				
					// Event listener for arhcive history button
					document.getElementById('archive-history').addEventListener('click', function() {
						openTab(options.calendarUrl);
					});
				
					// Event listener for archive version button
					document.getElementById('archive-version').addEventListener('click', function() {
						chrome.tabs.create({ url: archivedVersion}); 
					});
				
				} else { // Snapshot not returned
					display('loading','none'); // Hide loading text
					display('not-found','block');

					display('archive-version','none');
					display('archive-history','none');

					document.getElementById('details').style.height = '56px';
				}
			
			} else { // Server-side error  
				console.log(getTime() + 'API Data not fetched for ' + currentUrl);
			
				display('loading','none'); // Hide loading text
				display('not-found-2','block');

				display('archive-version','none');
				display('archive-history','none');
			}
		};

		request.onerror = function() { // Connection error
			console.log(getTime() + 'API Data not fetched for ' + currentUrl);
			
			display('loading','none'); // Hide loading text
			display('not-found-2','block');

			display('archive-version','none');
			display('archive-history','none');
		};

		request.send();
	}
	
	function openTab(type) { // Open archive save URL or history list URL in a new tab 
		
		if(valid['url'] == true && valid['disallowMatch'] == false) {
	
			console.log(getTime() + 'Opening URL : ' + currentUrl + ' | type ' + type);
			chrome.tabs.create({ url: type + currentUrl });		
			
		}
	
	}
	
	function getTime() { // Returns current time (for console.log only)
		
		var time = new Date();
		
		return ("0" + time.getHours()).slice(-2)   + ":" + 
			("0" + time.getMinutes()).slice(-2) + ":" + 
			("0" + time.getSeconds()).slice(-2) + " | ";
	}
	
	function formatTimeDate(type = 'date', timeDate) { // Formats the time and date stamp return by the Wayback API
		
		var output;
	
		if (typeof timeDate != 'undefined') {
			
			if (type == 'date') {
				
				var year = timeDate.substr(0, 4);
				var month = timeDate.substr(4, 2);
				var  day = timeDate.substr(6, 2);
				
				output = year + '/' + month + '/' + day;
				
			} else if(type == 'time') {
				
				var hour = timeDate.substr(8, 2);
				var min = timeDate.substr(10, 2);
				var sec = timeDate.substr(12, 2);
				
				output = hour + ':' + min + ':' + sec;
			}
			
			return output;
		}
		
	}
	
	function fetchNumber() { // Fetch number of pages archived by the user
		
		chrome.storage.sync.get({
			pagesArchived: 0, // Default
		}, function(items) {
			document.getElementById('total-number').innerHTML = items.pagesArchived;		
		});
		
	}
	
	function resetNumber() { // Reset number of pages archived
		
		chrome.storage.sync.set({'pagesArchived': 0}, function() {
			document.getElementById('total-number').innerHTML = '0';
			console.log(getTime() + 'Archived number reset to 0');
		});
		
	}
	
	function display(element, display = 'none') { // Change visibility of a html element
		
		if (typeof element != 'undefined') {

			document.getElementById(element).style.display = display;
		}
		
	}
}