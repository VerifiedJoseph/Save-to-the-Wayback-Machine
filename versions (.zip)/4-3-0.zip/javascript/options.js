/*jslint node: true */
/*global chrome */
'use strict';

var userOptions = {};
var defaultUserOptions = {};
var options = {};

// Functions
function status(text) { // Set options status text
	
	var div = document.getElementById('status');
	
	div.textContent = text;

	setTimeout(function () {
		div.textContent = '';
	}, 1750);
	
}

function saveOptions() { // Saves user options to chrome storage

	var optionsToSave = {
		consoleLog: document.getElementById('consol_log').checked,
	
		logNumberArchived: document.getElementById('log_number').checked,

		numberFormat: document.getElementById('number_format').value,
		
		dateFormat: document.getElementById('date_format').value,
		timeFormat: document.getElementById('time_format').value,
		timeZoneConvert: document.getElementById('time_zone_convert').checked,
		
		displayFullDate: document.getElementById('full_date_time').checked,
		displayTimeSince: document.getElementById('time_since_archive').checked,
			
		contextMenu: document.getElementById('context_menu').checked,
		contextMenuNote: document.getElementById('context_note').checked,
			
		notePlayAlert: document.getElementById('note_sound').checked,
		noteAlertSound: document.getElementById('note_sound_list').value,
			
		scanRobotsFile: document.getElementById('robots_txt_scan').checked,
		archiveAnyway: document.getElementById('archive_anyway').checked
	};
		
	//console.log(optionsToSave);
		
	chrome.storage.sync.set(optionsToSave, function () {
	
		if (chrome.runtime.lastError) {
    
			status('An error occurred, Try again');
     
		} else {
			
			status('Options saved');
			
		}
	});

}

// Display options
function displayOptions(showDefaults) {

	var list = userOptions;
	
	if (showDefaults === true) { // Show default user options
		
		list = defaultUserOptions;
		
	}
	
	if (list !== null) {
		
		document.getElementById('log_number').checked = list.logNumberArchived;
			
		document.getElementById('number_format').value = list.numberFormat;
			
		document.getElementById('date_format').value = list.dateFormat;
		document.getElementById('time_format').value = list.timeFormat;
		document.getElementById('time_zone_convert').checked = list.timeZoneConvert;
		
		document.getElementById('full_date_time').checked = list.displayFullDate;
		document.getElementById('time_since_archive').checked = list.displayTimeSince;
	
		document.getElementById('context_menu').checked = list.contextMenu;
		document.getElementById('context_note').checked = list.contextMenuNote;
			
		document.getElementById('note_sound').checked = list.notePlayAlert;
		document.getElementById('note_sound_list').value = list.noteAlertSound;
			
		document.getElementById('robots_txt_scan').checked = list.scanRobotsFile;
		document.getElementById('archive_anyway').checked = list.archiveAnyway;

		document.getElementById('consol_log').checked = list.consoleLog;
			
		if (list.contextMenu === false) { // Disable context Menu note option, if contextMenu is false. 
			document.getElementById('context_note').disabled = true;
		}

		if (list.notePlayAlert === false) { // Disable Sounds list and preview, if notePlayAlert is false. 
			
			document.getElementById('note_sound_list').disabled = true;
			document.getElementById('preview_sound').disabled = true;
			document.getElementById('note-sound').className = 'disabled';
			
		}
			
		if (list.scanRobotsFile === false) { // Fade info text for robots.txt file scan
			
			//document.getElementById('note-rb').className = 'disabled';
			document.getElementById("archive_anyway").disabled = true;

		}
		
	}
	
	/*chrome.storage.sync.get(defaultUserOptions, function (items) {
		//console.log(items);
			
		document.getElementById('log_number').checked = items.logNumberArchived;
			
		document.getElementById('number_format').value = items.numberFormat;
			
		document.getElementById('date_format').value = items.dateFormat;
		document.getElementById('time_format').value = items.timeFormat;
		document.getElementById('time_zone_convert').checked = items.timeZoneConvert;
		
		document.getElementById('full_date_time').checked = items.displayFullDate;
		document.getElementById('time_since_archive').checked = items.displayTimeSince;
	
		document.getElementById('context_menu').checked = items.contextMenu;
		document.getElementById('context_note').checked = items.contextMenuNote;
			
		document.getElementById('note_sound').checked = items.notePlayAlert;
		document.getElementById('note_sound_list').value = items.noteAlertSound;
			
		document.getElementById('robots_txt_scan').checked = items.scanRobotsFile;
		document.getElementById('archive_anyway').checked = items.archiveAnyway;

		document.getElementById('consol_log').checked = items.consoleLog;
			
		if (items.contextMenu === false) { // Disable context Menu note option, if contextMenu is false. 
			document.getElementById('context_note').disabled = true;
		}

		if (items.notePlayAlert === false) { // Disable Sounds list and preview, if notePlayAlert is false. 
			
			document.getElementById('note_sound_list').disabled = true;
			document.getElementById('preview_sound').disabled = true;
			document.getElementById('note-sound').className = 'disabled';
			
		}
			
		if (items.scanRobotsFile === false) { // Fade info text for robots.txt file scan
			
			//document.getElementById('note-rb').className = 'disabled';
			document.getElementById("archive_anyway").disabled = true;

		}
	
	}); */
}

function resetOptions() { // Reset user options to defaults in chrome storage

	chrome.storage.sync.set(defaultUserOptions, function (items) {
		// Update status to let user know options were reset.
		var status = document.getElementById('status');
		status.textContent = 'Options reset.';

		setTimeout(function () {
			status.textContent = '';
		}, 1750);
			
	});
}
	
function background(name, variable, callback) { // Sends a message to background.js to run a function.
		
	chrome.runtime.sendMessage({name: name, variable: variable}, function (response) {

		if (name === 'options') {
			
			options = response.variable.options;
			userOptions = response.variable.userOptions;
			
			defaultUserOptions = response.variable.defaultUserOptions;
	
		}

		callback();
		
	});
	
}
	
function previewSound() { // Preview selected notification alert sound 
	
	var sound = document.getElementById('note_sound_list').value,
		file = options.alertSounds[sound];
	
	if (typeof file !== 'undefined') {

		var preview = new Audio('../sounds/' + file);
		preview.play();
		
	}
}


document.addEventListener('DOMContentLoaded', function () { // Event listener for DOMContentLoaded
		
	// Fetch options (all) from the background.js and user options with callback
	background('options', false, displayOptions);
		
	// Event listener for input box clicks (buttons, checkbox etc..)		
	var body = document.querySelector("body");
	
	body.addEventListener('click', function (event) {
		var input = event.target;
			
		// Check Boxes
		if (input.id === 'context_menu') { // Right Click Menus
				
			if (input.checked) {

				document.getElementById("context_note").disabled = false;

			} else {

				document.getElementById("context_note").disabled = true;
				
			}
				
		} else if (input.id === 'note_sound') { // Notifications (Sound)
				
			if (input.checked) {

				document.getElementById("note_sound_list").disabled = false;
				document.getElementById("preview_sound").disabled = false;
				document.getElementById('note-sound').className = '';

			} else {

				document.getElementById("note_sound_list").disabled = true;
				document.getElementById("preview_sound").disabled = true;
				document.getElementById('note-sound').className = 'disabled';
	
			}
				
		} else if (input.id === 'robots_txt_scan') { // Robots.txt file scan
				
			if (input.checked) {

				//document.getElementById('note-rb').className = '';
				document.getElementById("archive_anyway").disabled = false;
					
			} else {
					
				//document.getElementById('note-rb').className = 'disabled';
				document.getElementById("archive_anyway").disabled = true;
				
			}
		
		// Radio
		} else if (input.id === 'full_date_time') { // Display full date and time
			
			if (input.checked) {

				document.getElementById('note-date').className = '';
				document.getElementById('note-time').className = '';
				
				document.getElementById("date_format").disabled = false;
				document.getElementById("time_format").disabled = false;
	
			}

		} else if (input.id === 'time_since_archive') { // Display time since last archive
			
			if (input.checked) {

				document.getElementById('note-date').className = 'disabled';
				document.getElementById('note-time').className = 'disabled';
				
				document.getElementById("date_format").disabled = true;
				document.getElementById("time_format").disabled = true;

			}
	
		// Buttons
		} else if (input.id === 'preview_sound') { // Preview notification sound 

			previewSound();
	
		} else if (input.id === 'save') { // Save user options

			saveOptions();
			
		} else if (input.id === 'reset') { // Reset user options
			
			document.getElementById('confirm').style.display = 'block'; // Show confirm div
	
		} else if (input.id === 'no') { // No, Hide confirm div
	
			document.getElementById('confirm').style.display = 'none'; // Hide confirm div 
	
		} else if (input.id === 'yes') { // Yes, Reset user options confirmed
	
			resetOptions();
			displayOptions(true); // Display default user options
			
			// 
			//background('options', false, displayOptions);
	
			document.getElementById('confirm').style.display = 'none'; // Hide confirm div 
	
		}
		
	});
});
