/*jslint node: true */
/*global chrome */
"use strict";

// Hard coded options
var valid = {};
var saved = {};
var options = {
	urls: {
		save: 'https://web.archive.org/save/',
		calendar: 'https://web.archive.org/web/*/',
		api: 'https://archive.org/wayback/available?url='
	},
	regex: {
		url: /^https?:\/\/[a-zA-Z0-9-.]{2,256}\.[a-z]{2,20}\/[a-zA-Z0-9@:%_\+.~#?&\/\/=\-]*/i, // URL validation
		path: /^https?:\/\/[a-zA-Z0-9-.]{2,256}\.[a-z]{2,20}(\/[a-zA-Z0-9@:%_\+.~#?!&\/\/=\-]*)/i, // Returns the file path fom a URL
		ipv4: /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/g, // IPv4 validation
		// Disallow
		disallow: /^Disallow:([a-zA-Z0-9@:%_\+.~#?&\/\/=\-*$]*)$/i,
		DisallowWord: /^\Disallow\b/i,
		// Allow
		allow: /^allow:([a-zA-Z0-9@:%_\+.~#?&\/\/=\-*$]*)$/i,
		allowWord: /^\allow\b/i,
		// User Agent
		userAgent: /^User-Agent: ([a-zA-Z0-9@:%_\+.~#?&\/\/=\-*()]*)$/i,
		userAgentWord: /^\bUser-Agent\b/i
	},
	//regexIPv4: /^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/,
	protocolBlackList: ['chrome:', 'chrome-extension:', 'ftp:', 'file:', 'view-source:'],
	hostNameBlackList: ['web.archive.org', '127.0.0.1'],
	alertSounds: ['served-alert.mp3', 'job-done.mp3'],
	requestedBy: 'Save to the Wayback Machine (https://verifiedjoseph.com/wayback)'
};

// Default User Options date
var defaultDate = new Date();
defaultDate.setHours(0);
defaultDate.setMinutes(0);
defaultDate.setSeconds(0);
defaultDate.setMilliseconds(0);

// Default User Options
var defaultUserOptions = {
	// Page Archived and number format
	numberFormat: '1,000', // Format to display numbers
	//archived: 0, // Total number of pages archived
	//archivedToday: 0, // Number of pages archived today
	//archivedYesterday: 0, // Number of pages archived yesterday

	archivedDate: defaultDate.getTime(), // Current date at install

	consoleLog: false, // Log actions in dev console

	logNumberArchived: true, // Log number of pages archived

	// Date and time formats
	dateFormat: 'F j, Y',
	timeFormat: 'g:i A',
	timeZoneConvert: true,
	displayFullDate: true,
	displayTimeSince: false,

	// Context Menus
	contextMenu: true, // Show 'Archive this' link is the context menu
	contextMenuNote: true, // Display note if a page cannot be archived via the context menu

	// Notifications
	notePlayAlert: false, // Play alert sound when a notification is displayed.
	noteAlertSound: 0, // Default Alert sound.

	// Scan robots.txt file
	scanRobotsFile: false, // Scan each website's robots.txt file
	archiveAnyway: false // Show 'archive anyway' button if request is blocked by robots.txt
};

// User options from chrome.storage
var userOptions = {};

var contextMenuSet = false;

// Functions
function fetchUserOptions(callback) { // Fetch user options

	chrome.storage.sync.get(defaultUserOptions, function (items) {
		userOptions = items; // Pass options to var userOptions;

		callback();
	});

}

function getTime() { // Returns current time (for console.log only)

	var time = new Date();

	return ("0" + time.getHours()).slice(-2)   + ":" +
		("0" + time.getMinutes()).slice(-2) + ":" +
		("0" + time.getSeconds()).slice(-2) + " | ";
	
}

function consoleLog(text, showTime) { // Log text and time with console.log

	if (userOptions.consoleLog === true) {

		if (showTime === false) { // No time

			console.log(text);

		} else { // Show time

			console.log(getTime() + text);

		}
	}

}

function contextMenus() {  // Create or remove context menus

	if (contextMenuSet === false && userOptions.contextMenu === true) { // Create 'Archive this' context menu

		chrome.contextMenus.create({
			"title": "Archive this page",
			"contexts": ["page"],
			"id": "archivePage"
		}, function () {
			
			if (chrome.extension.lastError) {
				consoleLog("Got expected error: " + chrome.extension.lastError.message);
			}
			
		});

		contextMenuSet = true;

	} else if (contextMenuSet === true && userOptions.contextMenu === false) { // Remove 'Archive this' context menu

		chrome.contextMenus.removeAll(function () {
			
			if (chrome.extension.lastError) {
				
				consoleLog("Got expected error: " + chrome.extension.lastError.message);
				
			}
		});

		contextMenuSet = false;

	}
}

function vaildateUrl(url, callback) { // Vaildate Url

	var parser = document.createElement('a'); // Get URL parts
	parser.href = url;
	
	// Vaildate URL or an IPv4 address using regular expressions
	if (url.match(options.regex.url) || url.match(options.regex.ipv4)) {

		// Loop through protocol black list
		options.protocolBlackList.forEach(function (protocol) {

			if (parser.protocol === protocol) { // Protocol match
				valid.url = false;
			}
			
		});

		// Loop through host name black list
		options.hostNameBlackList.forEach(function (host) {
			
			if (parser.hostname === host) { // host name match
				valid.url = false;
			}
			
		});

	} else {
		
		valid.url = false;
		consoleLog('URL not valid: ' + url);
	
	}
}

function scanRobotsFile(url, callback) { // Scans each website's robots.txt file to see if a page can be archived.

	if (userOptions.scanRobotsFile === true && valid.url === true) { // Is enabled and URL is valid

		// Regular expression and other vars
		var userAgentMatched = false,
			parser = document.createElement('a'), // Get URL parts
			matchUserAgent,
			agentType = null,
			matchDisallow,
			matchAllow,
			matchDisallowLength,
			path,
			currentLine = null, // Type of the current robots.txt line
			previousLine = null, // Type of the previous robots.txt line
			pageRequest = new XMLHttpRequest();

		parser.href = url;
		path = url.match(options.regex.path);
		
		pageRequest.open('GET', parser.protocol + '//' + parser.hostname + '/robots.txt', true);
		pageRequest.setRequestHeader('x-requested-by', options.requestedBy);

		pageRequest.onload = function () {
			
			if (this.status >= 200 && this.status < 400) { // Check HTTP status code

				consoleLog('Fetched robots.txt file for ' + parser.hostname);
				consoleLog('Starting file scan...');

				var data = this.response.split('\n'),
					line,
					number;

				for (number = 0; number < data.length; number += 1) { // Loop throught each line of the file
					
					line = data[number].trim();
					
					if (line.length === 0) { // Blank line 
						
						currentLine = 'blank';
						
						consoleLog('#' + number + '| Blank ', false);
						
					} else if (line.charAt(0) === '#') { // Comment line 
						
						currentLine = 'comment';
						
						consoleLog('#' + number + '| Comment ', false);
						
					} else if (line.match(options.regex.userAgentWord)) { // User agent line
						
						currentLine = 'user-agent';
						
						matchUserAgent = line.match(options.regex.userAgent); // Get user agent string
						
						if (matchUserAgent[1] === '*' || matchUserAgent[1] === 'ia_archiver' || matchUserAgent[1] === 'archive.org_bot') { // Match UA string 
							consoleLog('#' + number + '| Matched user agent : ' + matchUserAgent[1], false);
							
							userAgentMatched = true;
							
						} else { // User agent not matched 
							consoleLog('#' + number + '| User agent : ' + matchUserAgent[1], false);
							
							userAgentMatched = false;
							
						}
						
					} else if (line.match(options.regex.DisallowWord) && userAgentMatched === true) { // Disallow line
						
						currentLine = 'disallow';
	
						line = line.replace(/\s+/g, ''); // Remove spaces from bady written lines
						
						matchDisallow = line.match(options.regex.disallow);
						
						if (matchDisallow === null) {  // Disallow has no path
							consoleLog('#' + number + '| Matched Disallow, User agent allow to crawl whole website.', false);

							valid.disallowMatch = false;
							break;
							
						} else if (matchDisallow[1] === '/') { // User agent not allow to crawl website.
							consoleLog('#' + number + '| Matched Disallow (: /), User agent not allow to crawl website.', false);

							valid.disallowMatch = true;
							break;
							
						} else if (path[1] === matchDisallow[1]) { // User agent not allow to crawl current URL
							consoleLog('#' + number + '| Matched Disallow : "' + matchDisallow[1] + '"', false);

							valid.disallowMatch = true;
							break;
							
						} else {
							
							consoleLog('#' + number + '| Disallow: ' + matchDisallow[1], false);
							
						}
	
					} else if (line.match(options.regex.allowWord) && userAgentMatched === true) { // Allow line
						
						currentLine = 'allow';
						
						line = line.replace(/\s+/g, ''); // Remove spaces from bady written lines
						
						matchAllow = line.match(options.regex.allow);
						
						if (matchAllow === null) {  // Allow has no path
							consoleLog('#' + number + '| Matched Allow, User agent allow to crawl whole website.', false);

							valid.disallowMatch = false;
							break;
							
						} else if (matchAllow[1] === '/') { // User agent allow to crawl website.
							consoleLog('#' + number + '| Matched Allow (: /), User agent allow to crawl whole website.', false);

							valid.disallowMatch = false;
							break;
							
						} else if (path[1] === matchAllow[1]) { // User agent not allow to crawl current URL
							consoleLog('#' + number + '| Matched Allow : "' + matchAllow[1] + '"', false);

							valid.disallowMatch = false;
							break;
							
						} else {
							
							consoleLog('#' + number + '| Allow: ' + matchAllow[1], false);
							
						}
						
					} else { // Unkown line or disallow not for matched user agent
						
						consoleLog('#' + number + '| ' + line, false);
						
					}
					
				}
				
				consoleLog('Stopped robots.txt file scan.\n UA matched: ' + userAgentMatched + '\n Disallow matched: ' + valid.disallowMatch + '\n Total lines: ' + data.length + '\n Lines scanned: ' + number);
				callback();

			} else { // Server-side error

				consoleLog('robots.txt file not fetched for ' + parser.hostname + ' (Server-side error)');
				callback();
				
			}
		};

		pageRequest.onerror = function () { // Connection error

			consoleLog('robots.txt file not fetched for ' + parser.hostname + ' (Connection error)');
			callback();

		};

		pageRequest.send();

	}
	
}

function vaildate(url, callback) { // Vaildate URL and scan robots.txt file

	valid = { // Defaults
		url: true, // URL is vaild
		disallowMatch: false, // Robots.txt disallow match
		metaTagFound: false
	};

	var parser = document.createElement('a'); // Get URL parts
	parser.href = url;
	
	// Vaildate URL or an IPv4 address using regular expressions
	if (url.match(options.regex.url) || url.match(options.regex.ipv4)) {

		// Loop through protocol black list
		options.protocolBlackList.forEach(function (protocol) {

			if (parser.protocol === protocol) { // Protocol match
				valid.url = false;
			}
			
		});

		// Loop through host name black list
		options.hostNameBlackList.forEach(function (host) {
			
			if (parser.hostname === host) { // host name match
				valid.url = false;
			}
			
		});

	} else {
		
		valid.url = false;
		consoleLog('URL not valid: ' + url);
	
	}
	

	if (valid.url === true && userOptions.scanRobotsFile === true) { // URL is valid and file scan is enabled

		scanRobotsFile(url, callback); // Scan robots.txt for disallow match and run callback

	} else { // URL is not vaild, Run callback

		callback();

	}

}

function saveByAjax(url, callback) { // Save by ajax to the save URL

	saved = { // Defaults
		saved: false,
		pageLocation: '',
		error: '',
		errorCode: 200
	};

	var request = new XMLHttpRequest();
	request.open('GET', options.urls.save + url, true);
	request.setRequestHeader('x-requested-by', options.requestedBy);

	request.onload = function () {

		saved.errorCode = this.status;
		
		if (this.status === 200) { // Check HTTP status codes

			var archivedLocation = request.getResponseHeader('Content-Location');

			if (archivedLocation !== null) {

				saved.saved = true;
				saved.pageLocation = archivedLocation;

			}
			
		// Server-side errors
		} else if (this.status === 502) {

			saved.error = 'Wayback Machine was unable to save the page.<BR/><BR/> Try agian later.';
			
		} else {

			var runtimeError = request.getResponseHeader('X-Archive-Wayback-Runtime-Error').split(':');

			if (runtimeError[0] === 'AdministrativeAccessControlException') { // Black listed website

				saved.error = 'Website has been excluded from the Wayback Machine.';

			} else if (runtimeError[0] === 'RobotAccessControlException') { // Blocked By robots.txt file

				saved.error = 'Request blocked by robots.txt file.';

			} else if (runtimeError[0] === 'LiveDocumentNotAvailableException') { // IA faild to fetch page

				saved.error = 'Wayback Machine was unable to save the page.<br/><br/> Try agian later.';

			} else { // Unkown Error

				saved.error = 'An unkown error occurred.';

			}
		}

		callback();

	};

	request.onerror = function () { // Connection error

		saved.saved = false;
		saved.errorCode = this.status;
		saved.error = 'An unkown error occurred.';

		callback();

	};

	request.send();

}

function openTab(url) { // Create new tab

	if (valid.url === true && valid.disallowMatch === false) {

		chrome.tabs.create({
			url: options.saveUrl + url
		});

	}

}

function getRandomId() { // Creates a somewhat random ID

	var id = Math.floor(Math.random() * 9007199254740992) + 1;
	return id.toString();

}

function notifyUser(url) { // Show notification if URL is not vaild (Right click menu only)

	if (userOptions.contextMenuNote === true) { // Is enabled

		var id = getRandomId(),
			noteInfo = {
				title: 'This page can not be archived, Sorry!',
				iconUrl: '/images/icons/128.png',
				type: 'basic',
				message: ''
			};

		if (valid.url === false && valid.disallowMatch === false) { // URL not valid

			noteInfo.message = 'The Wayback Machine can not archive local files or pages from web.archive.org.';

		} else if (valid.url === true && valid.disallowMatch === true) { // Disallow match

			noteInfo.message = "Request blocked by robots.txt file.";

		}

		// Create notification
		chrome.notifications.create(id, noteInfo);

		// Log
		consoleLog("Created notification '" + noteInfo.message + "' ");
	}
}

function notifyUserSound() { // Plays alert along the notification, if enabled.

	if (userOptions.notePlayAlert === true) {

		var sound = userOptions.noteAlertSound,
			file = options.alertSounds[sound];

		if (typeof file !== 'undefined') {

			var audio = new Audio('sounds/' + file);
			audio.play();

			consoleLog("Played notification sound (#" + sound + ") ");
		}
	}

}

function updateStats() { // Update day stats
		
	chrome.storage.sync.get({
		// Defaults
		pagesArchived: 0,
		archivedToday: 0,
		archivedYesterday: 0
	}, function (items) {

		var oneDay = 60 * 60 * 24 * 1000, // 1 day in milliseconds
			dateNow = new Date(), // Time and date now
			storedDate = userOptions.archivedDate,
			daysPassed = Math.floor((dateNow.getTime() - storedDate) / oneDay); // Number of days passed

		consoleLog('Updating stats...');
		consoleLog(dateNow + ' ' + storedDate);
		consoleLog(daysPassed + ' full days between');

		if (daysPassed > 0) { // If a day(s) has passed, shift today & yesterday numbers

			if (daysPassed > 1) { // If more that one day has passed

				items.archivedYesterday = 0; // Yesterday
				items.archivedToday = 0; // Today

			} else { // Only one day has passed

				items.archivedYesterday = items.archivedToday; // Yesterday
				items.archivedToday = 0; // Today

			}

			// Set to zero
			dateNow.setHours(0);
			dateNow.setMinutes(0);
			dateNow.setSeconds(0);
			dateNow.setMilliseconds(0);

			chrome.storage.sync.set({
				'archivedDate': dateNow.getTime(),
				'pagesArchived': items.pagesArchived,
				'archivedToday': items.archivedToday,
				'archivedYesterday': items.archivedYesterday
			}, function () {
				
				consoleLog('Stats updated');
				
			});

		} else {
			
			consoleLog('Stats not updated, same day.');
			
		}

	});
	
}

function logNumber() { // Logs number

	if (userOptions.logNumberArchived === true) { // Log numbers if option in enabled
	
		chrome.storage.sync.get({
			// Defaults
			pagesArchived: 0,
			archivedToday: 0,
			archivedYesterday: 0
		}, function (items) {
		
			items.pagesArchived += 1;
			items.archivedToday += 1;

			chrome.storage.sync.set({
				'pagesArchived': items.pagesArchived,
				'archivedToday': items.archivedToday
			}, function () {

				consoleLog('Numbers updated');
			
			});
		});
		
	} else {
		
		consoleLog('Numbers not updated, option disabled');
		
	}
	
}

// On script load Fetch user options, create context menu and update stats
fetchUserOptions(function () { // Fetch user options
	updateStats();
	contextMenus();
});

// Listener for then the extension is installed or updated
chrome.runtime.onInstalled.addListener(function (details) {

	if (details.reason === "install") {
		console.log(getTime() + "This is a first install!");

	} else if (details.reason === "update") {
		var thisVersion = chrome.runtime.getManifest().version;

		console.log(getTime() + "Updated from " + details.previousVersion + " to " + thisVersion + "!");
	}
});

// Listener for then the extension is started
//chrome.runtime.onStartup.addListener(function() {});

// Listener for then the storage has changed
chrome.storage.onChanged.addListener(function (changes, namespace) {

	fetchUserOptions(function () { // Fetch user options and run contextMenus() function
		contextMenus();
	});

});

// Listener for on click of the context menu link
chrome.contextMenus.onClicked.addListener(function (info, tab) {
//console.log(info);

	vaildate(tab.url, function () {

		if (valid.url === true && valid.disallowMatch === false) { // URL is vaild, log number

			updateStats();
			logNumber();
			openTab(tab.url); // Open save URL

		} else { // Show Notification

			notifyUser(tab.url); // Show notification
			notifyUserSound(); // Play sound, if enabled

		}

	});
});

// Message listener for messages from pop.js
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	var responseLog, responseVariable;

	// Log request
	consoleLog('Request | ' + request.name + ' | variables : ' + request.variable);

	if (request.name === 'vaildate') { // Vaildate page URL or IPv4

		vaildate(request.variable, function () {

			sendResponse({name: 'vaildate', variable: valid});
			consoleLog('Response | ' + request.name + ' | variables : ' + valid);

		});

		return true;

	} else if (request.name === 'saveByAjax') { // Save URL by ajax GET request

		saveByAjax(request.variable, function () {

			sendResponse({name: 'saveByAjax', variable: saved});
			consoleLog('Response | ' + request.name + ' | variables : ' + saved);

			consoleLog(saved);
			
			if (saved.saved === true) { // log number if page was saved
				
				updateStats();
				logNumber();

			}

		});

		return true;

	} else if (request.name === 'options') { // All Options (options, userOptions and defaultUserOptions)

		responseVariable = {options: options, userOptions: userOptions, defaultUserOptions: defaultUserOptions};

		// Send Response to popup.js
		sendResponse({name: request.name, variable: responseVariable});

		// Log Response
		consoleLog('Response | ' + request.name + ' | variables : ' + responseVariable);

	} else if (request.name === 'updateStats') { // Update stats
		
		updateStats();
		sendResponse();
		consoleLog('Response | ' + request.name + ' | variables : false');
		
	}

});