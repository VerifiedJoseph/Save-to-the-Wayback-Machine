/*jslint node: true */
/*global chrome */
"use strict";

// Hard coded options
var wasReset = false;
var valid = {};
var saved = {};
var options = {
	urls: {
		save: 'https://web.archive.org/save/',
		calendar: 'https://web.archive.org/web/*/',
		api: 'https://archive.org/wayback/available?url='
	},
	regex: {
		url: /^https?:\/\/[a-zA-Z0-9-.]{2,256}\.[a-z]{2,20}\/[a-zA-Z0-9@:%_\+.~#?&\/\/=\-]*/i, // URL validation
		path: /^https?:\/\/[a-zA-Z0-9-.]{2,256}\.[a-z]{2,20}(\/[a-zA-Z0-9@:%_\+.~#?!&\/\/=\-]*)/i, // Returns the file path from a URL
		ipv4: /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/g, // IPv4 validation
		// HTTP status codes
		httpCodes : /^(200|201|202|203|301|302|303|307|308|400|401|403|404|405|406|408|409|411|412|413|414|415|418|429|431|451)$/
	},
	protocolBlackList: ['chrome:', 'chrome-extension:', 'ftp:', 'file:', 'view-source:'],
	hostNameBlackList: ['web.archive.org', '127.0.0.1'],
	alertSounds: ['served-alert.mp3', 'job-done.mp3'],
	requestedBy: 'Save to the Wayback Machine (https://verifiedjoseph.com/wayback)'
};

// Default User Options
var defaultUserOptions = {
	// Page Archived and number format
	numberFormat: '1,000', // Format to display numbers

	consoleLog: false, // Log actions in dev console

	logNumberArchived: true, // Log number of pages archived

	// Date and time formats
	dateFormat: 'F j, Y',
	timeFormat: 'g:i A',
	timeZoneConvert: true,
	displayFullDate: true,
	displayTimeSince: false,

	// Context Menu
	contextMenu: true, // Show 'Archive this' link is the context menu (right click menu)
	contextMenuNote: true, // Display notification if a page cannot be archived via the context menu

	// Notifications
	notePlayAlert: false, // Play alert sound when a notification is displayed.
	noteAlertSound: 0 // Default Alert sound.
};

// Default User Stats
var defaultUserStats = {
	pagesArchived: 0 // Total number of pages archived
};

// User options from chrome.storage
var userOptions = {};
var userStats = {};

var contextMenuSet = false;

// Functions
function fetchUserOptions(startup, callback) { // Fetch user options

	var defaults = defaultUserOptions;
	
	if (startup === true) { // Startup, fetch all item from storage including stats 
		
		defaults = Object.assign(defaultUserOptions, defaultUserStats);
		
	}
	
	chrome.storage.sync.get(defaults, function (items) {
		userOptions = items; // Pass options to var userOptions;
		
		callback();
	});

}

function getTime() { // Returns current time (for console.log only)

	var time = new Date();

	return ("0" + time.getHours()).slice(-2)   + ":" +
		("0" + time.getMinutes()).slice(-2) + ":" +
		("0" + time.getSeconds()).slice(-2) + " | ";
	
}

function consoleLog(text, showTime) { // Log text and time with console.log

	if (userOptions.consoleLog === true) {

		if (showTime === false) { // No time

			console.log(text);

		} else { // Show time

			console.log(getTime() + text);

		}
	}

}

function contextMenus() { // Create or remove context menus

	if (contextMenuSet === false && userOptions.contextMenu === true) { // Create 'Archive this' context menu

		chrome.contextMenus.create({
			"title": "Archive this page",
			"contexts": ["page"],
			"id": "archivePage"
		}, function () {
			
			if (chrome.extension.lastError) {
				consoleLog("Got expected error: " + chrome.extension.lastError.message);
			}
			
		});

		contextMenuSet = true;

	} else if (contextMenuSet === true && userOptions.contextMenu === false) { // Remove 'Archive this' context menu

		chrome.contextMenus.removeAll(function () {
			
			if (chrome.extension.lastError) {

				consoleLog("Got expected error: " + chrome.extension.lastError.message);

			}
		});

		contextMenuSet = false;

	}
}


function vaildate(url, callback) { // Vaildate URL and scan robots.txt file

	valid = { // Defaults
		url: true // URL is vaild
	};

	var parser = document.createElement('a'); // Get URL parts
	parser.href = url;
	
	// Vaildate URL or an IPv4 address using regular expressions
	if (url.match(options.regex.url) || url.match(options.regex.ipv4)) {

		// Loop through protocol black list
		options.protocolBlackList.forEach(function (protocol) {

			if (parser.protocol === protocol) { // Protocol match
				valid.url = false;
			}
			
		});

		// Loop through host name black list
		options.hostNameBlackList.forEach(function (host) {
			
			if (parser.hostname === host) { // host name match
				valid.url = false;
			}
			
		});

	} else {
		
		valid.url = false;
		consoleLog('URL not valid: ' + url);
	
	}

	callback();

}

function saveByAjax(url, callback) { // Save by ajax to the save URL

	saved = { // Defaults
		saved: false,
		pageLocation: '',
		error: '',
		errorCode: 200
	};

	var request = new XMLHttpRequest();
	request.open('GET', options.urls.save + url, true);
	request.setRequestHeader('x-requested-by', options.requestedBy);

	request.onload = function () {

		saved.errorCode = this.status;
		var statusCode = this.status.toString();
		
		// Check for Wayback Runtime Error header
		if (request.getResponseHeader('X-Archive-Wayback-Runtime-Error')) {
			
			var runtimeError = request.getResponseHeader('X-Archive-Wayback-Runtime-Error').split(':');
			
			if (runtimeError[0] === 'AdministrativeAccessControlException') { // Black listed website

				saved.error = 'Website is excluded from the Wayback Machine.';

			} else if (runtimeError[0] === 'RobotAccessControlException') { // Blocked By robots.txt file

				saved.error = 'Unable to save page. Blocked by robots.txt file.';

			} else if (runtimeError[0] === 'LiveDocumentNotAvailableException') { // IA faild to fetch page

				saved.error = 'Unable to save page.<br/><br/>Try again later.';

			} else { // Unkown Error

				saved.error = 'An unkown error occurred, try again later.';

			}
			
		} else if (statusCode.match(options.regex.httpCodes)) { // Check HTTP status codes
			
			var archivedLocation = request.getResponseHeader('Content-Location');

			if (archivedLocation !== null) {

				saved.saved = true;
				saved.pageLocation = archivedLocation;

			} else { // Unkown Error
			
				saved.error = 'An unkown error occurred, try again later.';
			
			}
			
		} else { // Unkown Error
			
			saved.error = 'An unkown error occurred, try again later.';
			
		}

		callback();

	};

	request.onerror = function () { // Connection error

		saved.saved = false;
		saved.errorCode = this.status;
		saved.error = 'An unkown error occurred.';

		callback();

	};

	request.send();

}

function openTab(url) { // Create new tab

	if (valid.url === true) {

		chrome.tabs.create({
			url: options.urls.save + url
		});

	}

}

function getRandomId() { // Creates a somewhat random ID

	var id = Math.floor(Math.random() * 9007199254740992) + 1;
	return id.toString();

}

function notifyUser(url) { // Show notification if URL is not vaild (Right click menu only)

	if (userOptions.contextMenuNote === true) { // Is enabled

		var id = getRandomId(),
			noteInfo = {
				title: 'This page can not be archived, Sorry!',
				iconUrl: '/images/icons/128.png',
				type: 'basic',
				message: ''
			};

		if (valid.url === false) { // URL not valid

			noteInfo.message = 'The Wayback Machine can not archive local files or pages from web.archive.org.';

		}

		// Create notification
		chrome.notifications.create(id, noteInfo);

		// Log
		consoleLog("Created notification '" + noteInfo.message + "' ");
	}
}

function notifyUserSound() { // Plays alert along the notification, if enabled.

	if (userOptions.notePlayAlert === true) {

		var sound = userOptions.noteAlertSound,
			file = options.alertSounds[sound];

		if (typeof file !== 'undefined') {

			var audio = new Audio('sounds/' + file);
			audio.play();

			// Log
			consoleLog("Played notification sound (#" + sound + ") ");
		}
	}

}

function resetStats(callback) { // Reset stats to zero

	wasReset = false; // Default
	
	chrome.storage.sync.set({
		'pagesArchived': 0
	}, function () {
	
		if (chrome.runtime.lastError) {
			consoleLog(chrome.runtime.lastError.message);
	
			wasReset = false;
		
		} else {
			consoleLog('Stats reset to zero');
	
			// Update user stats var
			userStats.pagesArchived = 0;
			
			wasReset = true;
			
		}

		callback();
	
	});
	
}

function logNumber() { // Logs number

	if (userOptions.logNumberArchived === true) { // Log numbers if option in enabled
		
		userStats.pagesArchived += 1;

		chrome.storage.sync.set({
			'pagesArchived': userStats.pagesArchived
		}, function () {
			
			consoleLog('Number updated');
			
		});

	} else {
		
		consoleLog('Number not updated, option disabled');
		
	}
	
}

// On script load Fetch user options, create context menu and update stats
fetchUserOptions(true, function () { // Fetch user options

	userStats = {
		pagesArchived: userOptions.pagesArchived
	};
	
	contextMenus();
});

// Listener for then the extension is installed or updated
chrome.runtime.onInstalled.addListener(function (details) {

	if (details.reason === "install") {
		console.log(getTime() + "This is a first install!");

	} else if (details.reason === "update") {
		var thisVersion = chrome.runtime.getManifest().version;

		console.log(getTime() + "Updated from " + details.previousVersion + " to " + thisVersion + "!");
	}
});

// Listener for then the extension is started
//chrome.runtime.onStartup.addListener(function() {});

// Listener for then the storage has changed
chrome.storage.onChanged.addListener(function (changes, namespace) {

	fetchUserOptions(false, function () { // Fetch user options and run contextMenus() function
		contextMenus();
	});

});

// Listener for on click of the context menu link
chrome.contextMenus.onClicked.addListener(function (info, tab) {
	
	vaildate(tab.url, function () {

		if (valid.url === true) { // URL is vaild, log number
			logNumber();
			openTab(tab.url); // Open save URL

			console.log('hello');
			
		} else { // Show Notification

			notifyUser(tab.url); // Show notification
			notifyUserSound(); // Play sound, if enabled

		}

	});
});

// Message listener for messages from pop.js
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	var responseLog, responseVariable;

	// Log request
	consoleLog('Request | ' + request.name + ' | variables : ' + request.variable);

	if (request.name === 'vaildate') { // Vaildate page URL or IPv4

		vaildate(request.variable, function () {

			sendResponse({name: 'vaildate', variable: valid});
			consoleLog('Response | ' + request.name + ' | variables : ' + valid);

		});

		return true;

	} else if (request.name === 'saveByAjax') { // Save URL by ajax GET request

		saveByAjax(request.variable, function () {

			sendResponse({name: 'saveByAjax', variable: saved});
			consoleLog('Response | ' + request.name + ' | variables : ' + saved);

			consoleLog(saved);
			
			if (saved.saved === true) { // log number if page was saved

				logNumber();

			}

		});

		return true;

	} else if (request.name === 'options') { // All Options (options, userOptions and defaultUserOptions)

		responseVariable = {options: options, userOptions: userOptions, defaultUserOptions: defaultUserOptions};

		// Send Response to popup.js
		sendResponse({name: request.name, variable: responseVariable});

		// Log Response
		consoleLog('Response | ' + request.name + ' | variables : ' + responseVariable);

	} else if (request.name === 'userStats') { // Fetch user stats 

		// Send Response to popup.js
		sendResponse({name: 'userStats', variable: userStats});
		
		// Log Response
		consoleLog('Response | ' + request.name + ' | variables : ' + userStats);

	} else if (request.name === 'updateStats') { // Update stats

		sendResponse();
		consoleLog('Response | ' + request.name + ' | variables : false');
		
	} else if (request.name === 'resetStats') { // Rest stats
		
		resetStats(function () {
			// Send Response to popup.js
			sendResponse({name: 'resetStats', variable: wasReset});
			
			// Log Response
			consoleLog('Response | ' + request.name + ' | variables : ' + wasReset);
			
		});

		return true;
	
	}

});