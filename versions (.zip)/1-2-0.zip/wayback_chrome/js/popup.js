// C:\Users\Joseph\AppData\Local\Google\Chrome\User Data\Default\Extensions\ppokigfjbmhncgkabghdgpiafjdpllke\0.1.1_0
$(document).ready(function () {
	//chrome.browserAction.setBadgeText({text:"Dev"});
	
	var currentUrl;
	var archivedVersion;
	var expression = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
	var saveUrl = 'http://web.archive.org/save/';
	var calendarUrl = 'https://web.archive.org/web/*/';
	var apiUrl = 'https://archive.org/wayback/available?url=';	
	var validUrl = true;
	var protocolBlackList = ['chrome:','chrome-extension:','ftp:','file:']
	
	chrome.tabs.query({currentWindow: true, active: true}, function(tabs) { // Current tab URL		
		currentUrl = tabs[0].url; // Current tab URL
		
		var parser = document.createElement('a'); // Get URL parts
		parser.href = currentUrl;
		
		//console.log(parser.protocol);
		//console.log(parser.hostname);
		
		for (i = 0; i < protocolBlackList.length; i++) { // Loop 
			if(parser.protocol == protocolBlackList[i]) { // If current URL and black list protocol match
				validUrl = false;
				break;
			}
		}
		
		if(validUrl == true) { // If URl passed the protocol black lots check   
			
			// Validate URl with regex
			var regex = new RegExp(expression);
		
			if (currentUrl.match(regex)) {
				fetchData(); // Fetch API data 
			
				// Archive button clicked
				$('.archive-now').on("click", function () {
					openUrl(saveUrl);
				});
			
				// Archive list button clicked
				$('.archive-list').on("click", function () {
					openUrl(calendarUrl);
				});
			
				// Archive version button clicked
				$('.archive-last-link').on("click", function () {
					chrome.tabs.create({ url: archivedVersion}); 
				});
			
			} else {
				$('.loading').hide();
				$('.error').show();
			}	
		} else {
			$('.loading').hide();
			$('.error').show();
		}
	});
	
	function openUrl(type) { // Open archive save/list in a new tab  
		//chrome.tabs.create({ url: 'http://127.0.0.1/save/'+ currentUrl }); // Test 
		chrome.tabs.create({ url: type + currentUrl }); // Live 
	}
	
	function fetchData() { // Fetch data about this page from the Wayback Machine API
		
		$.ajaxSetup({dataType:'json'}); // set data type
	
		$.getJSON(apiUrl + currentUrl)
	
		.done(function(data) {
			console.log( "Data fetched : true" );
			console.log(data);
					
			if(data['archived_snapshots'].hasOwnProperty('closest')) {
				$('.loading').hide();	

				archivedVersion = data['archived_snapshots']['closest']['url'];
				
				var timestamp = data['archived_snapshots']['closest']['timestamp'];
				
				var dateYear = timestamp.substr(0, 4);
				var dateMonth = timestamp.substr(4, 2);
				var dateDay = timestamp.substr(6, 2);
				
				var timeHour = timestamp.substr(8, 2);
				var timeMin = timestamp.substr(10, 2);
				var timeSec = timestamp.substr(12, 2);
				
				var fullDate = dateYear + '/' + dateMonth + '/' + dateDay;
				var fullTime = timeHour + ':' + timeMin + ':' + timeSec;
				
				$(".date").append(fullDate + ' ' + fullTime);
				$(".date-title").show();
				$(".date").show();
				
				$(".status").append(data['archived_snapshots']['closest']['status']);
				$('.status-title').show();
				$('.status').show();
				
			} else {
				$('.loading').hide();
	
				$('.not-found').show();
				
				$('.date-title').hide();
				$('.date').hide();
				
				$('.status-title').hide();
				$('.status').hide();
				
				$('.archive-last-link').hide();	
				$('.archive-list').hide();	
			}
		})
	
		.fail(function() {
			console.log( "Data fetched : false" );
			
			$('.loading').hide();
			
			$('.not-found-2').show();
				
			$('.date-title').hide();
			$('.date').hide();
				
			$('.status-title').hide();
			$('.status').hide();
				
			$('.archive-last-link').hide();	
		});
		
	}

});