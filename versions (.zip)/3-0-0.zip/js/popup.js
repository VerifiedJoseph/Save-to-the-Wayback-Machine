window.onload = function() {
	//chrome.browserAction.setBadgeText({text:"Dev"});
	
	var currentUrl;
	var archivedVersion; // Archived version url returned in the web archive API. 
	var validUrl = true;

	var options = {}; // Hard coded options
	var userOptions = {}; // User options
		
	// Fetch hard coded options from the background page  
	chrome.runtime.getBackgroundPage(function (bgp) {
		options = bgp.fetchOptions();
    });
	
	// Event listener for opening options page
	document.getElementById('options').addEventListener('click', function() {
		if (chrome.runtime.openOptionsPage) { // New way to open options pages, if supported (Chrome 42+).

			chrome.runtime.openOptionsPage();
		} else {
			window.open(chrome.runtime.getURL('options.html')); // Reasonable fallback. (Chrome <41)
		}
	});
	
	// Event listener for opening stats view
	document.getElementById('stats').addEventListener('click', function() {
		document.getElementById('stats-view').style.display = 'block';
		document.getElementById('options-box').style.display = 'none';
		
		fetchNumber();
	});
	
	// Event listener for closing stats view (back)
	document.getElementById('back').addEventListener('click', function() {
		document.getElementById('stats-view').style.display = 'none';
		document.getElementById('options-box').style.display = 'block';
	});
	
	// Event listener for resetting stats number
	document.getElementById('reset-number').addEventListener('click', function() {
		if(confirm("Are you sure you?")) {
			resetNumber();
		}
	});
	
	chrome.tabs.query({currentWindow: true, active: true}, function(tabs) { // Current tab URL		
		currentUrl = tabs[0].url; // Current tab URL
		
		console.log(currentUrl);
		
		var parser = document.createElement('a'); // Get URL parts
		parser.href = currentUrl;
		
		// Loop through protocol black list
		for (i = 0; i < options.protocolBlackList.length; i++) { 
			if(parser.protocol == options.protocolBlackList[i]) { // If current URL and black list protocol match
				validUrl = false;
				break;
			}
		}
		
		// Loop through host name black list
		for (i = 0; i < options.hostNameBlackList.length; i++) { 
			if(parser.hostname == options.hostNameBlackList[i]) { // If current URL and host Name protocol match
				validUrl = false;
				break;
			}
		}
		
		if(validUrl == true) { // If URl passed the protocol black lots check   
			
			// Validate URl with regex
			var regex = new RegExp(options.expression);
		
			if (currentUrl.match(regex)) {
				fetchData(); // Fetch API data 
			
				// Event listener for arhcive now button
				document.getElementById('archive-now').addEventListener('click', function() {
					chrome.runtime.getBackgroundPage(function (bgp) {
						bgp.logNumber(); // Logs number (function from background.js)
						openTab(options.saveUrl); //  Open tab
					});
				});
				
				// Event listener for arhcive history button
				document.getElementById('archive-history').addEventListener('click', function() {
					openTab(options.calendarUrl);
				});
				
				// Event listener for archive version button
				document.getElementById('archive-version').addEventListener('click', function() {
					chrome.tabs.create({ url: archivedVersion}); 
				});

			} else { // Regex failed (pahe can not be archived)
				document.getElementById('loading').style.display = 'none';
				document.getElementById('error').style.display = 'block';
			}	
		} else { // Protocol/Host Name black list match
			document.getElementById('loading').style.display = 'none';
			document.getElementById('error').style.display = 'block';
		}
	});
	

	function openTab(type) { // Open archive save/list in a new tab 
		console.log(getTime() + 'Opening URL : ' + currentUrl + ' | type ' + type);
		chrome.tabs.create({ url: type + currentUrl });
	}
	
	function fetchData() { // Fetch data about current page from the Wayback Machine API
		
		var request = new XMLHttpRequest();
		request.open('GET', options.apiUrl + currentUrl, true);

		request.onload = function() {
			if (this.status >= 200 && this.status < 400) {
				// Success!
				var data = JSON.parse(this.response);
			
				console.log(getTime() + "Data fetched : true" );
				console.log(data);
	
				// If the API has returned a snapshot
				if(data['archived_snapshots'].hasOwnProperty('closest')) {
					document.getElementById('loading').style.display = 'none';

					archivedVersion = data['archived_snapshots']['closest']['url'];
				
					var timestamp = data['archived_snapshots']['closest']['timestamp'];
				
					var dateYear = timestamp.substr(0, 4);
					var dateMonth = timestamp.substr(4, 2);
					var dateDay = timestamp.substr(6, 2);
				
					var timeHour = timestamp.substr(8, 2);
					var timeMin = timestamp.substr(10, 2);
					var timeSec = timestamp.substr(12, 2);
				
					var fullDate = dateYear + '/' + dateMonth + '/' + dateDay;
					var fullTime = timeHour + ':' + timeMin + ':' + timeSec;
				
					// Date
					document.getElementById("date").innerHTML = fullDate;
					document.getElementById('date-title').style.display = 'block';
				
					// Time 
					document.getElementById("time").innerHTML = fullTime;
					document.getElementById('time-title').style.display = 'block';
				
				} else { // Snapshot not returned
					document.getElementById('loading').style.display = 'none';
					document.getElementById('not-found').style.display = 'block';

					document.getElementById('archive-version').style.display = 'none';
					document.getElementById('archive-history').style.display = 'none';

					document.getElementById('details').style.height = '56px';
				}
			
			} else { // Server-side error  
				console.log(getTime() + "Data fetched : false" );
			
				document.getElementById('loading').style.display = 'none';
				document.getElementById('not-found-2').style.display = 'block';

				document.getElementById('archive-version').style.display = 'none';
				document.getElementById('archive-history').style.display = 'none';
			}
		};

		request.onerror = function() { // Connection error
			console.log(getTime() + "Data fetched : false" );
			
			document.getElementById('loading').style.display = 'none';
			document.getElementById('not-found-2').style.display = 'block';

			document.getElementById('archive-version').style.display = 'none';
			document.getElementById('archive-history').style.display = 'none';
		};

		request.send();
	}
		
	function fetchNumber() { // Fetch number of pages archived by user
		
		chrome.storage.sync.get({
			pagesArchived: 0, // Default
		}, function(items) {
			document.getElementById('total-number').innerHTML = items.pagesArchived;		
		});
		
	}  
	
	function resetNumber() { // Reset number of pages archived
		
		chrome.storage.sync.set({'pagesArchived': 0}, function() {
			document.getElementById('total-number').innerHTML = '0';
			console.log(getTime() + 'Archived number reset to 0');
		});
		
	}
	
	function getTime() { // Returns current time (for console.log only)
		
		var time = new Date();
		
		return ("0" + time.getHours()).slice(-2)   + ":" + 
			("0" + time.getMinutes()).slice(-2) + ":" + 
			("0" + time.getSeconds()).slice(-2) + " | ";
	}
};