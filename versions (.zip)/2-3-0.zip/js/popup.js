$(document).ready(function () {	
	//chrome.browserAction.setBadgeText({text:"Dev"});
	
	var currentUrl;
	var archivedVersion; // Archived version url returned in the web archive API. 
	var validUrl = true;
	
	var options = {}; // Hard coded options
	var userOptions = {}; // User options
		
	// Fetch hard coded options from the background page  
	chrome.runtime.getBackgroundPage(function (bgp) {
		options = bgp.fetchOptions();
    });
	

	// Open options page on div click
	$('#options, #options-two').on("click", function() {
		if (chrome.runtime.openOptionsPage) {
			// New way to open options pages, if supported (Chrome 42+).
			chrome.runtime.openOptionsPage();
		} else {
			// Reasonable fallback.
			window.open(chrome.runtime.getURL('options.html'));
		}
	});
	
	// Show/hide stats view on div click
	$('#stats, #stats-two').on("click", function() {
		$('.stats').show();
		fetchNumber();
	});
	
	$('#back').on("click", function() {
		$('.stats').hide();
	});
	
	$('#reset-number').on("click", function() {
		if(confirm("Are you sure you?")) {
			resetNumber();
		} else {
			return false;
		}
	});
	
	chrome.tabs.query({currentWindow: true, active: true}, function(tabs) { // Current tab URL		
		currentUrl = tabs[0].url; // Current tab URL
		
		var parser = document.createElement('a'); // Get URL parts
		parser.href = currentUrl;
		
		// Loop through protocol black list
		for (i = 0; i < options.protocolBlackList.length; i++) { 
			if(parser.protocol == options.protocolBlackList[i]) { // If current URL and black list protocol match
				validUrl = false;
				break;
			}
		}
		
		// Loop through host name black list
		for (i = 0; i < options.hostNameBlackList.length; i++) { 
			if(parser.hostname == options.hostNameBlackList[i]) { // If current URL and host Name protocol match
				validUrl = false;
				break;
			}
		}
		
		if(validUrl == true) { // If URl passed the protocol black lots check   
			
			// Validate URl with regex
			var regex = new RegExp(options.expression);
		
			if (currentUrl.match(regex)) {
				fetchData(); // Fetch API data 
			
				// Archive button clicked
				$('#archive-now').one("click", function() {
					chrome.runtime.getBackgroundPage(function (bgp) {
						bgp.logNumber(); // Logs number (function from background.js)
						openTab(options.saveUrl); //  Open tab
					});
				});
			
				// Archive list button clicked
				$('#archive-history').on("click", function() {
					openTab(options.calendarUrl);
				});
			
				// Archive version button clicked
				$('#archive-version').on("click", function() {
					chrome.tabs.create({ url: archivedVersion}); 
				});
			
			} else { // Regex failed 
				$('.loading').hide();
				$('.error').show();
			}	
		} else { // Protocol/Host Name black list match
			$('.loading').hide();
			$('.error').show();
		}
	});
	
	function openTab(type) { // Open archive save/list in a new tab 
		console.log(getTime() + 'Opening URL : ' + currentUrl + ' | type ' + type);
		chrome.tabs.create({ url: type + currentUrl });
	}
	
	function fetchData() { // Fetch data about this page from the Wayback Machine API
		
		$.ajaxSetup({dataType:'json'}); // set data type
		$.getJSON(options.apiUrl + currentUrl)
	
		.done(function(data) {
			console.log(getTime() + "Data fetched : true" );
			console.log(data);
	
			if(data['archived_snapshots'].hasOwnProperty('closest')) { // If the API has returned a snapshot
				$('.loading').hide();

				archivedVersion = data['archived_snapshots']['closest']['url'];
				
				var timestamp = data['archived_snapshots']['closest']['timestamp'];
				
				var dateYear = timestamp.substr(0, 4);
				var dateMonth = timestamp.substr(4, 2);
				var dateDay = timestamp.substr(6, 2);
				
				var timeHour = timestamp.substr(8, 2);
				var timeMin = timestamp.substr(10, 2);
				var timeSec = timestamp.substr(12, 2);
				
				var fullDate = dateYear + '/' + dateMonth + '/' + dateDay;
				var fullTime = timeHour + ':' + timeMin + ':' + timeSec;
				
				// Date
				$(".date").append(fullDate);
				$(".date-title").show();
				
				// Time 
				$(".time").append(fullTime);
				$(".time-title").show();
				
			} else { // Snapshot not returned
				$('.loading').hide();
	
				$('.not-found').show();
				
				$('.date-title').hide();
				$('.time-title').hide();
				$('#archive-version').hide();
				$('#archive-history').hide();
				
				$('.details').height(56);
			}
		})
	
		.fail(function() { // API request failed 
			console.log(getTime() + "Data fetched : false" );
			
			$('.loading').hide();
			
			$('.not-found-2').show();
				
			$('.date-title').hide();
			$('.time-title').hide();
			$('#archive-version').hide();
			$('#archive-history').hide();
		});
		
	}
		
	function fetchNumber() { // Fetch number of pages archived by user
		
		chrome.storage.sync.get({
			// Default
			pagesArchived: 0,
		}, function(items) {
			$('#total-number').html(items.pagesArchived);			
		});
		
	}  
	
	function resetNumber() { // Reset number of pages archived
		
		chrome.storage.sync.set({'pagesArchived': 0}, function() {
			$('#total-number').html(0); // Update html 
			console.log(getTime() + 'Archived number reset to 0');
		});
		
	}
	
	function getTime() { // Returns current time (for console.log only)
		
		var time = new Date();
		
		return ("0" + time.getHours()).slice(-2)   + ":" + 
			("0" + time.getMinutes()).slice(-2) + ":" + 
			("0" + time.getSeconds()).slice(-2) + " | ";
	}
	
});