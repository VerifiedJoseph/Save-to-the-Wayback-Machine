
	document.addEventListener('DOMContentLoaded',function() { // Event listener DOMContentLoaded
		
		restoreOptions(); // Display options from chrome.storage
	
		// Event listener for Show 'Archive this' checkbox
		document.getElementById('context_menu').addEventListener('change', function(event) {
			var checkbox = event.target;
			
			console.log(event.target);
			
			if (checkbox.checked) {

				console.log("The check box is checked.");
				document.getElementById("context_note").disabled = false;
			} else {
				console.log("The check box is not checked.");
				document.getElementById("context_note").disabled = true;
			}
		});
			
		document.getElementById('save').addEventListener('click',saveOptions); // Event listener for saving options
	});
	
	// Saves options to chrome storage
	function saveOptions() {
		var logNumber = document.getElementById('log_number').checked;
		var contextMenuShow = document.getElementById('context_menu').checked;
		var contextNoteShow = document.getElementById('context_note').checked;
  
		chrome.storage.sync.set({
			logNumberArchived: logNumber,
			contextMenu: contextMenuShow,
			contextMenuNote: contextNoteShow
		}, function() {
	
			// Update status to let user know options were saved.
			var status = document.getElementById('status');
			status.textContent = 'Options saved.';
			setTimeout(function() {
				status.textContent = '';
			}, 1750);
		});
	}

	// Restores checkbox state using the preferences stored in chrome.storage.
	function restoreOptions() {

		chrome.storage.sync.get({
			// Use default values
			logNumberArchived: true,
			contextMenu: true,
			contextMenuNote: false
		}, function(items) {
			
			console.log(items);
			
			document.getElementById('log_number').checked = items.logNumberArchived;
			document.getElementById('context_menu').checked = items.contextMenu;
			document.getElementById('context_note').checked = items.contextMenuNote;
			
			if(items.contextMenu == false) { // Hide context Menu note option, if contextMenu is false 
				document.getElementById("context_note").disabled = true;
			}
			
		});
	}
	
	function fg(){
		
	}