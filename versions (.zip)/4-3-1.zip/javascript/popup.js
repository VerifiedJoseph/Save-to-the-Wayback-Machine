/*jslint node: true */
/*global chrome */
'use strict';

var currentUrl,
	archivedVersion, // Archived version url returned in the web archive API.
	archivedLocation, // Archived Location (saving with ajax)
	valid = {},
	saved = {},
	options = {}, // Hard coded options
	userOptions = {}; // User options

function display(element, type) { // Change visibility of a html element
	/*
		var element - HTML element ID
		var display - Show or hide to element
	*/

	if (typeof element !== 'undefined') {
		document.getElementById(element).style.display = type;
	}

}

function updateHTML(element, data) { // Update the inner html/text of a html element
	/*
		var element - HTML element ID
		var data - Text or HTMl to add to the element
	*/

	if (typeof element !== 'undefined') {
		document.getElementById(element).innerHTML = data;
	}

}

function formatNumber(n) { // Format numbers to user set format
	/*
		var n - number to format
	*/

	var regex = /(\d+)(\d{3})/,
		format;

	if (userOptions.numberFormat === '1,000') {

		format = ',';

	} else if (userOptions.numberFormat === '1 000') {

		format = ' ';

	} else if (userOptions.numberFormat === '1.000') {

		format = '.';

	} else if (userOptions.numberFormat === '1\'000') {
		
		format = '\x27';
		
	}

	if (n >= 1000) {
		n = n.toString();

		while (regex.test(n)) {
			
			n = n.replace(regex, '$1' + format + '$2');
			
		}
	}

	return n;

}
	
function getTime() { // Returns current time (for console.log only)

	var time = new Date(),
		currentTime;

	currentTime = ("0" + time.getHours()).slice(-2)   + ":" +
		("0" + time.getMinutes()).slice(-2) + ":" +
		("0" + time.getSeconds()).slice(-2) + " | ";
	
	return currentTime;
	
}

function consoleLog(text, showTime) { // Logs text and time with console.log
	/*
		var text - Text to write to the browser's dev console
		var showTime - Show or hide the time (true/false)
	*/

	if (userOptions.consoleLog === true) {

		if (showTime === false) { // No time

			console.log(text);

		} else { // Show time

			console.log(getTime() + text);

		}
	}
}

function background(name, variable, callback) { // Sends a message to background.js to run a function.

	chrome.runtime.sendMessage({name: name, variable: variable}, function (response) {

		if (name === 'options') { // Pass options to the callback function

			//console.log(getTime() + 'Options fetched from background.js');
			callback(response.variable);

		} else { // Pass whole response to the callback function
			
			callback(response);
		
		}

	});

}

function openTab(type, override) { // Open archive save URL or history list URL in a new tab
	/*
		var type - type of url to open
		var override - Override valid['disallowMatch'] value and open save tab
	*/

	if ((valid.url === true && valid.disallowMatch === false) || (valid.url === true && override === true)) {

		consoleLog('Opening URL : ' + currentUrl + ' | type ' + type);
		chrome.tabs.create({ url: type + currentUrl });

	}

}

function timeSince(timeDate) { // Displays time since last archive. e.g: "1 hour ago"
	
	// Time stamp parts
	var year = timeDate.substr(0, 4),
		month = timeDate.substr(4, 2),
		day = timeDate.substr(6, 2),
		hour = timeDate.substr(8, 2),
		min = timeDate.substr(10, 2),
		sec = timeDate.substr(12, 2),
		date;
	
	if (userOptions.timeZoneConvert === true) { // Convert to local timezone

		var UTC = month + '/' + day + '/' + year + ' ' + hour + ':' + min + ':' + sec + ' UTC',
			UTCtime = new Date(UTC); // Convert to local timezone
		
		UTCtime.toLocaleString();

		// Fetch Local Time stamp parts
		date = new Date(UTCtime);

	} else {
	
		date = new Date(month + '/' + day + '/' + year + ' ' + hour + ':' + min + ':' + sec);
	
	}
	
	var seconds = Math.floor((new Date() - date) / 1000),
		interval = Math.floor(seconds / 31536000);

  if (interval > 1) {
		return interval + " years ago";
  }
	
  interval = Math.floor(seconds / 2592000);
  
	if (interval > 1) {
		return interval + " months ago";
  }
  
	interval = Math.floor(seconds / 86400);
  
	if (interval > 1) {
    return interval + " days ago";
  }
  
	interval = Math.floor(seconds / 3600);
  
	if (interval > 1) {
		return interval + " hours ago";
	}
  
	interval = Math.floor(seconds / 60);
	
	if (interval > 1) {
		return interval + " minutes ago";
	}
	
	return Math.floor(seconds) + " seconds ago";
	
}

function formatTimeDate(type, timeDate) { // Formats the time and date stamp return by the Wayback API
	/*
		var type - Return date or time for a timestamp
		var timeDate - date time string
	*/

	var output,
		months = {'01': "January", '02': "February", '03': "March", '04': "April", '05': "May", '06': "June", '07': "July", '08': "August", '09': "September", '10': "October", '11': "November", '12': "December"};

	if (typeof timeDate !== 'undefined') {

		// Time stamp parts
		var year = timeDate.substr(0, 4),
			month = timeDate.substr(4, 2),
			day = timeDate.substr(6, 2),
			hour = timeDate.substr(8, 2),
			min = timeDate.substr(10, 2),
			sec = timeDate.substr(12, 2);

		if (userOptions.timeZoneConvert === true) { // Convert to local timezone

			var UTC = month + '/' + day + '/' + year + ' ' + hour + ':' + min + ':' + sec + ' UTC',
				UTCtime = new Date(UTC); // Convert to local timezone
			UTCtime.toLocaleString();

			// Fetch Local Time stamp parts
			var localTime = new Date(UTCtime);

			year = localTime.getFullYear();
			month = localTime.getMonth() + 1;
			day = localTime.getDate();

			hour = localTime.getHours();
			min = localTime.getMinutes();
			sec = localTime.getSeconds();

		}

		if (type === 'date') {

			// Add leading zero, if not present
			if (day < 10 && day.toString().length === 1) {
				day = '0' + day;
			}

			if (month < 10 && month.toString().length === 1) {
				month = '0' + month;
			}

			if (userOptions.dateFormat === 'F j, Y') { // F j, Y - June 5, 2016

				if (day < 10) { // Removed starting zero
					day = day.substr(1);
				}

				output = months[month] + ' ' + day + ', ' + year;

			} else if (userOptions.dateFormat === 'Y/m/d') { // Y/m/d - 2016/06/05

				output = year + '/' + month + '/' + day;

			} else if (userOptions.dateFormat === 'd/m/Y') { // d/m/Y - 05/06/2016

				output = day + '/' + month + '/' + year;

			} else if (userOptions.dateFormat === 'm/d/Y') { // m/d/Y - 06/05/2016

				output = month + '/' + day + '/' + year;

			}

		} else if (type === 'time') {

			var ap = 'AM';

			// Add leading zero for hour, min and sec, if not present
			if (hour < 10 && hour.toString().length === 1) {
				hour = '0' + hour;
			}

			if (min < 10 && min.toString().length === 1) {
				min = '0' + min;
			}

			if (sec < 10 && sec.toString().length === 1) {
				sec = '0' + sec;
			}

			if (userOptions.timeFormat === 'H:i') { // H:i - 14:50

				output = hour + ':' + min;

			} else if (userOptions.timeFormat === 'H:i:s') { // H:i:s - 14:50:48

				output = hour + ':' + min + ':' + sec;

			} else { // g:i A - 02:50 (PM/AM) and g:i:s A - 02:50:48 (PM/AM)

				if (hour > 12) {

					hour -= 12;
					ap = "PM";

				} else if (hour === 0) {

					hour = 12;

				}

				// Add leading zero to hour, if not present after changing to 12 hour clock
				if (hour < 10 && hour.toString().length === 1) {
					hour = '0' + hour;
				}

				if (userOptions.timeFormat === 'g:i A') {  // Without seconds

					output = hour + ':' + min + ' ' + ap;

				} else { // With seconds

					output = hour + ':' + min + ':' + sec + ' ' + ap;

				}
			}
		}

		return output;

	}

}

function displayData(json) { // Formats and dsplay data  return by the Wayback Machine API 
	
	var data = JSON.parse(json),
		timeStamp,
		altTtext;

	consoleLog('API Data fetched for ' + currentUrl);
	consoleLog(data, false);

	// If the API has returned a snapshot
	if (data.archived_snapshots.hasOwnProperty('closest')) {
		display('loading', 'none'); // Hide loading text

		archivedVersion = data.archived_snapshots.closest.url;
		timeStamp = data.archived_snapshots.closest.timestamp;

		if (userOptions.displayFullDate === true) { // Display Full date and time 

			updateHTML('date', formatTimeDate('date', timeStamp)); // Date
			updateHTML('time', formatTimeDate('time', timeStamp)); // Time
			display('time-date', 'block'); // Show time and date
	
		} else { // Display time since
	
			altTtext = timeSince(timeStamp) + ' on ' + formatTimeDate('date', timeStamp) + ' at ' + formatTimeDate('time', timeStamp);
	
			updateHTML('since', timeSince(timeStamp));
			document.getElementById('since').title = altTtext;
			display('time-since', 'block'); // Show time and date
	
		}
	
		// Event listener for arhcive history button
		document.getElementById('archive-history').addEventListener('click', function () {
			openTab(options.urls.calendar);
		});

		// Event listener for archive version button
		document.getElementById('archive-version').addEventListener('click', function () {
			chrome.tabs.create({ url: archivedVersion});
		});

	} else { // Snapshot not returned

		consoleLog(getTime() + 'No snapshot returned for ' + currentUrl);
	
		display('loading', 'none'); // Hide loading text
		display('api-error-one', 'block');

		display('archive-version', 'none');
		display('archive-history', 'none');

	}
	
}

function fetchData() { // Fetch data about current page from the Wayback Machine API

	var request = new XMLHttpRequest();
	request.open('GET', options.urls.api + currentUrl, true);
	request.setRequestHeader('x-requested-by', options.requestedBy);

	request.onload = function () {
		if (this.status >= 200 && this.status < 400) { // Check HTTP status codes
			
			displayData(this.response);

		} else { // Server-side error
			consoleLog(getTime() + 'API Data not fetched for ' + currentUrl);

			display('loading', 'none'); // Hide loading text
			display('api-error-two', 'block');

			display('archive-version', 'none');
			display('archive-history', 'none');
		}
	};

	request.onerror = function () { // Connection error
		consoleLog('API Data not fetched for ' + currentUrl);

		display('loading', 'none'); // Hide loading text
		display('api-error-two', 'block');

		display('archive-version', 'none');
		display('archive-history', 'none');
	};

	request.send();
}

function wasSaved(response) { // Check If background funtions saved the page

	console.log(response);
	
	saved = response.variable;

	var archivingDiv = document.getElementById('archiving');

	display('loading-an', 'none'); // Hide archiving loading div

	if (saved.saved !== true) { // Page was not saved

		archivingDiv.querySelector('#title').innerHTML = "Page Not Archived";
		archivingDiv.querySelector('#reason').innerHTML = saved.error;

	} else { // Page saved

		archivedLocation = saved.pageLocation;

		archivingDiv.querySelector('#title').innerHTML = "Page Archived";

		display('archive-version-e', 'block'); // Show button

		//Add event listener for button
		document.getElementById('archive-version-e').addEventListener('click', function () {

			var archivedVersionUrl = 'https://web.archive.org' + archivedLocation;
			chrome.tabs.create({ url: archivedVersionUrl});

		});

	}

}

function isValid(response) { // Check if background function found the URL/IPv4 valid

	valid = response.variable;

	var errorDiv = document.getElementById('error');

	if (valid.url === true && valid.disallowMatch === false) { // Valid URL and not blocked by robots.txt

		consoleLog('URL: ' + currentUrl + ' is valid');
		
		// Event listener for archive now button
		document.getElementById('archive-now').addEventListener('click', function () {

			display('archiving', 'block'); // Show archiving div
	
			background('saveByAjax', currentUrl, wasSaved);
	
		});
		
		fetchData(); // Fetch API data

	} else if (valid.disallowMatch === true) { // robots.txt Disallow match

		if (valid.url === true) {

			consoleLog('URL: ' + currentUrl + ' is valid');

		}

		consoleLog('Request blocked by robots.txt file.');
		errorDiv.querySelector('#reason').innerHTML = 'Request blocked by robots.txt file.';  // Update reason

		display('loading', 'none'); // Hide loading text
		display('error', 'block'); // Show error box

		// Remove event listeners
		
		if (userOptions.archiveAnyway === true) {

			display('archive-anyway', 'block'); // Show archive anyway button

			// Set button click event listener for archive anyway button
			document.getElementById('archive-anyway').addEventListener('click', function () {

				if (userOptions.tabFreeArchiving === true) { // Achive page by XMLHttpRequest , if enabled

					background('saveByAjax', currentUrl, wasSaved);

					display('error', 'none'); // Hide error div
					display('archive-anyway', 'none'); // Hide archive anyway button div
					display('archiving', 'block'); // Show archiving div

				} else { // Achive page by open save URL in a tab

					openTab(options.urls.save, true); //  Open tab, overriding valid['disallowMatch']

				}
			});
		}

	} else { // URL not valid

		consoleLog('URL: ' + currentUrl + ' is not valid');
		errorDiv.querySelector('#reason').innerHTML = 'URL or IP address is not valid';  // Update reason

		display('loading', 'none'); // Hide loading text
		display('error', 'block'); // Show error box

	}

}


function wasRest(response) { // Check If background function has reset the stats
	
	if (response.variable === true) {
		
		updateHTML('total-number', 0);
		updateHTML('number-today', 0);
		updateHTML('number-yesterday', 0);
		
	} else {
		
		consoleLog('Stats not reset by background.js');
		
	}
	
	display('confirm', 'none'); // Hide comfirm yes/no box
	
}

function fetchNumber() { // Fetch number of pages archived by the user

	background('userStats', false, function (response) {

		var stats = response.variable;
		
		console.log(stats);
		
		// Display numbers
		updateHTML('total-number', formatNumber(stats.pagesArchived));
		updateHTML('number-today', formatNumber(stats.archivedToday));
		updateHTML('number-yesterday', formatNumber(stats.archivedYesterday));
		
	});
	
	/*chrome.storage.sync.get({
		// Defaults
		pagesArchived: 0,
		archivedToday: 0,
		archivedYesterday: 0
	}, function (items) {

		// Display numbers
		updateHTML('total-number', formatNumber(items.pagesArchived));
		updateHTML('number-today', formatNumber(items.archivedToday));
		updateHTML('number-yesterday', formatNumber(items.archivedYesterday));

	});*/

}

function eventListeners() { // Event listeners that must be created after the user options have been fetch from the background script  
	
	// Event listener for opening/closing the stats view, if logNumberArchived option in enabled
	if (userOptions.logNumberArchived === true) {
	
		// Opening
		document.getElementById('stats').addEventListener('click', function () {

			display('stats-view', 'block');
			display('options-box', 'none');

			background('updateStats', false, fetchNumber);

		});
		
		// Closing (back)
		document.getElementById('back').addEventListener('click', function () {

			display('stats-view', 'none');
			display('options-box', 'block');

		});

		// Resetting stats
		document.getElementById('reset-number').addEventListener('click', function () {

			display('confirm', 'block');
		
			document.getElementById('yes').addEventListener('click', function () {

				background('resetStats', false, wasRest);

				display('confirm', 'none');

			});
		
			document.getElementById('no').addEventListener('click', function () {

				display('confirm', 'none');

			});
		
		});
		
	} else { // Not enabled, disable the button
		
		document.getElementById('stats').className = 'left button small two disabled';
		document.getElementById('stats').title = 'Statistics are disabled';
		
	}
	
}

function start(allOptions) { // Start

	options = allOptions.options;
	userOptions = allOptions.userOptions;

	eventListeners();
}

// ON LOAD
window.onload = function () {
	
	background('options', false, start); // Fetch user options
	
	chrome.tabs.query({currentWindow: true, active: true}, function (tabs) { // Current tab URL

		currentUrl = tabs[0].url;
		background('vaildate', currentUrl, isValid); // Vaildate current Tab URL

	});

	// Event listener for opening options page
	document.getElementById('options').addEventListener('click', function () {

		window.open(chrome.runtime.getURL('html/options.html'));

	});
};