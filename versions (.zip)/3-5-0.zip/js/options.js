
	document.addEventListener('DOMContentLoaded',function() { // Event listener DOMContentLoaded
		
		displayOptions(); // Display options from chrome.storage
	
		// Event listener for Show 'Archive this' checkbox
		document.getElementById('context_menu').addEventListener('change', function(event) {
			var checkbox = event.target;
			
			console.log(event.target);
			
			if (checkbox.checked) {
				document.getElementById("context_note").disabled = false;
			} else {
				document.getElementById("context_note").disabled = true;
			}
		});
			
		 // Event listener for saving options
		document.getElementById('save').addEventListener('click',saveOptions);
		
		// Event listener for resetting options button
		document.getElementById('reset').addEventListener('click', function() {
			document.getElementById('confirm').style.display = 'block'; // Show confirm div 
			
			// Event listener for no button
			document.getElementById('no').addEventListener('click', function() {
				document.getElementById('confirm').style.display = 'none'; // Hide confirm div 
			});
			
			// Event listener for yes button
			document.getElementById('yes').addEventListener('click', function() {
				resetOptions();
				displayOptions();
				document.getElementById('confirm').style.display = 'none'; // Hide confirm div 
			});
			
		});
		
	});
	
	// Saves options to chrome storage
	function saveOptions() {
		var logNumber = document.getElementById('log_number').checked;
		var contextMenuShow = document.getElementById('context_menu').checked;
		var contextNoteShow = document.getElementById('context_note').checked;
  
		chrome.storage.sync.set({
			logNumberArchived: logNumber,
			contextMenu: contextMenuShow,
			contextMenuNote: contextNoteShow
		}, function() {
	
			// Update status to let user know options were saved.
			var status = document.getElementById('status');
			status.textContent = 'Options saved.';
			setTimeout(function() {
				status.textContent = '';
			}, 1750);
		});
	}

	// Restores (displays) checkboxes state using the options stored in chrome.storage.
	function displayOptions() {

		chrome.storage.sync.get(function(items) {
			
			console.log(items);
			
			document.getElementById('log_number').checked = items.logNumberArchived;
			document.getElementById('context_menu').checked = items.contextMenu;
			document.getElementById('context_note').checked = items.contextMenuNote;
			
			if(items.contextMenu == false) { // Hide context Menu note option, if contextMenu is false. 
				document.getElementById("context_note").disabled = true;
			}
			
		});
	}
	
	// Reset options in chrome storage
	function resetOptions() {

		chrome.storage.sync.set({
			// Use default values
			logNumberArchived: true,
			contextMenu: true,
			contextMenuNote: true
		}, function(items) {
			
			// Update status to let user know options were reset.
			var status = document.getElementById('status');
			status.textContent = 'Options reset.';
			setTimeout(function() {
				status.textContent = '';
			}, 1750);
			
		});
	}