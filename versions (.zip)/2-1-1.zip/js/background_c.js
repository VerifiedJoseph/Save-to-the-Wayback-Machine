	
	// Hrad coded options
	var expression = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
	var saveUrl = 'http://web.archive.org/save/';
	var validUrl = true;
	var menuCreated = false;
	var protocolBlackList = ['chrome:','chrome-extension:','ftp:','file:']
	
	// User set options - chrome.storage options vars
	var userOptions = {};
	var contextMenu;
	var contextMenuNote;
	var logNumberArchived;
	
	function fetchOptions() {  // Fetch options from chrome.storage
		
		chrome.storage.sync.get({
			// Use default values
			logNumberArchived: true,
			contextMenu: true,
			contextMenuNote: false
		}, function(items) {
			console.log(items);
	
			//console.log(userOptions);
			
			contextMenu = items.logNumberArchived;
			contextMenuNote = items.contextMenu;
			logNumberArchived = items.contextMenuNote;
			
			console.log("fetch :" + contextMenu);
			
			return items;
		});
		
	}
	
	function vaildateUrl(url) {
		
		var parser = document.createElement('a'); // Get URL parts
		parser.href = url;
		
		console.log(parser.href);
		
		for (i = 0; i < protocolBlackList.length; i++) { // Loop 
			if(parser.protocol == protocolBlackList[i]) { // If current URL and black list protocol match
				validUrl = false;
				break;
			}
		}
		
		if(validUrl == true) { // If URl passed the protocol black lots check   
			
			// Validate URl with regex
			var regex = new RegExp(expression);
		
			if (!url.match(regex)) {
				validUrl = false;
			} else {
				console.log('Valid URL: ' + url);
				
			}
		}
		
	}
	
	function createMenu() {
		
		if(menuCreated == false) {
			menuCreated = true;
			
			chrome.contextMenus.create({
				"title": "Archive this page",
				"contexts": ["page"],
				"id": "archive"
			}, function() {
				if (chrome.extension.lastError) {
					console.log("Got expected error: " + chrome.extension.lastError.message);
				}
			});
		}
		
	}
	
	function removeMenu() {
		
		if(menuCreated == true) {
			menuCreated = false;
			
			chrome.contextMenus.removeAll(function() {
				if (chrome.extension.lastError) {
					console.log("Got expected error: " + chrome.extension.lastError.message);
				}
			});
		}
		
	}
	
	// On install/Update
	chrome.runtime.onInstalled.addListener(function(details) {
    
		if(details.reason == "install") {
			console.log("This is a first install!");
		
			chrome.storage.sync.set({ // Set default user options 
				logNumberArchived: true,
				contextMenu: true,
				contextMenuNote: false
			}, function() {
				console.log("First install, user option saved.");
			});
			
			userOptions = fetchOptions();
			createMenu();
			
		} else if(details.reason == "update") {
			var thisVersion = chrome.runtime.getManifest().version;
			console.log("Updated from " + details.previousVersion + " to " + thisVersion + "!");
		}
	});
	
	// storage onChange re-fetch user options 
	chrome.storage.onChanged.addListener(function(changes, namespace) {
		
		userOptions = fetchOptions();
		
		for (key in changes) {
			var storageChange = changes[key];
			console.log('Storage key "%s" in namespace "%s" changed. ' +
			'Old value was "%s", new value is "%s".',
			key,
			namespace,
			storageChange.oldValue,
			storageChange.newValue);
        }
		
		alert(contextMenu);
		
		/*if(userOptions.contextMenu == true && menuCreated == false) { // Context Menu is enabled
			alert('c');
			createMenu(); // Create the contex menu 
		
		} else if(userOptions.contextMenu == false && menuCreated == true) { // Context Menu is disabled
			alert('r');
			removeMenu();
		}*/
		
	});
			
	/*chrome.tabs.onActivated.addListener(function(tab) {
			validUrl = true; // Default
		
			chrome.tabs.query({currentWindow: true, active: true}, function(tab) { // Current tab URL		
				console.log('hello: ' + tab[0].url);
			
				vaildateUrl(tab[0].url);

				removeMenu();
				createMenu();
			
				console.log(validUrl);
				console.log('---');
			});
		
			//console.log('hello: ' + tab.url);
			chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
				if (changeInfo.status == "complete") {
					console.log(tab.url + '| updated');
				
					console.log('hello: ' + tab.url);
			
					vaildateUrl(tab.url);

					removeMenu();
					createMenu();
			
					console.log(validUrl);
					console.log('---');
				}
			});
		});	*/
			
	
	/*chrome.tabs.query({currentWindow: true, active: true}, function(tabs) { // Current tab URL		
		currentUrl = tabs[0].url; // Current tab URL
		
		var parser = document.createElement('a'); // Get URL parts
		parser.href = currentUrl;
		
		for (i = 0; i < protocolBlackList.length; i++) { // Loop 
			if(parser.protocol == protocolBlackList[i]) { // If current URL and black list protocol match
				validUrl = false;
				break;
			}
		}
		
		if(validUrl == true) { // If URl passed the protocol black lots check   
			
			// Validate URl with regex
			var regex = new RegExp(expression);
		
			if (currentUrl.match(regex)) {
			
				chrome.contextMenus.create({
					"title": "Archive this page",
					"contexts": ["page"],
					"id": "context" + 'page'
				}, function() {
					if (chrome.extension.lastError) {
						console.log("Got expected error: " + chrome.extension.lastError.message);
					}
				});	
				
				
			}
		}
	});*/


/*chrome.contextMenus.create({
	"title": "Archive this page",
    "contexts": ["page"],
	"id": "context" + 'page'
    }, function() {
  if (chrome.extension.lastError) {
    console.log("Got expected error: " + chrome.extension.lastError.message);
  }
});*/

chrome.contextMenus.onClicked.addListener(archivePage);

function archivePage(info, tab) {
	var searchstring = info.selectionText;
 
	console.log(tab);
	console.log(info);
 
	alert(searchstring);
 
 //chrome.tabs.create({url: "http://maps.google.com/maps?q=" + searchstring})
}