	
	// Hard coded options
	var expression = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
	var saveUrl = 'http://web.archive.org/save/';
	var validUrl = true;
	var menuCreated = false;
	var protocolBlackList = ['chrome:','chrome-extension:','ftp:','file:']
	
	// User set options - chrome.storage options
	var userOptions = {};
	
	chrome.runtime.onInstalled.addListener(function(details) { // On Install/Update
    
		if(details.reason == "install") {
			console.log("This is a first install!");
		
			chrome.storage.sync.get({ // Fetch user options
				// Use default values
				logNumberArchived: true,
				contextMenu: true,
				contextMenuNote: false
			}, function(items) {
			
				passOptions(items); // Pass options from chrome.storage to var userOptions;
				createMenu(items); // Create context menu and pass options
			});
			
		} else if(details.reason == "update") {
			var thisVersion = chrome.runtime.getManifest().version;
			console.log("Updated from " + details.previousVersion + " to " + thisVersion + "!");
			
			chrome.storage.sync.get(function(items) {
			
				passOptions(items); // Pass options from chrome.storage to var userOptions;
				createMenu(items); // Create context menu and pass options
			});
		}
	});
	
	chrome.runtime.onStartup.addListener(function() { // On Startup

		chrome.storage.sync.get({ // Fetch user options
			// Use default values
			logNumberArchived: true,
			contextMenu: true,
			contextMenuNote: false
		}, function(items) {
			
			passOptions(items); // Pass options from chrome.storage to var userOptions;
			createMenu(items); // Create context menu and pass options
		});
	});
	
	chrome.storage.onChanged.addListener(function(changes, namespace) { // On storage change (user options)

		chrome.storage.sync.get(function(items) {			
			passOptions(items); // Pass options from chrome.storage to var userOptions;
			createMenu(items); // Create context menu (if not)
			removeMenu(items); // Create context menu (if not)
		
		});

	});
	
	chrome.contextMenus.onClicked.addListener(function(info, tab) { // On click of the context menu link
 
		vaildateUrl(tab.url);
		openTab(saveUrl,tab.url);
		notifyUser(tab.url); // Show notification if is URL not vaild

	});
	
	
	// Functions	
	function passOptions(options) {  // Pass options from chrome.storage to var userOptions;
		
		userOptions = options;
		
	}
	
	function createMenu(options) { // Create context menu
		
		if(menuCreated == false && options.contextMenu == true) {
			menuCreated = true;
			
			chrome.contextMenus.create({
				"title": "Archive this page",
				"contexts": ["page"],
				"id": "archive"
			}, function() {
				if (chrome.extension.lastError) {
					console.log("Got expected error: " + chrome.extension.lastError.message);
				}
			});
		} else {
			console.log('Context menu not created (user option)');	
		}
		
	}
	
	function removeMenu(options) { // Remove set context menu
		
		if(menuCreated == true && options.contextMenu == false) {
			console.log('Context menu removed (user option)');
			
			menuCreated = false;
			
			chrome.contextMenus.removeAll(function() {
				if (chrome.extension.lastError) {
					console.log("Got expected error: " + chrome.extension.lastError.message);
				}
			});
		}
		
	}
	
	function vaildateUrl(url) { //Vaildate Url
		
		validUrl = true; // Default
		
		var parser = document.createElement('a'); // Get URL parts
		parser.href = url;
		
		// Loop through protocol black list
		for (i = 0; i < protocolBlackList.length; i++) {
			if(parser.protocol == protocolBlackList[i]) { // If current URL and black list protocol match
				validUrl = false;
				break;
			}
		}
		
		if(validUrl == true) { // If URl passed the protocol black lots check   
			
			// Validate URl with regex
			var regex = new RegExp(expression);
		
			if (!url.match(regex)) {
				validUrl = false;
			} else {
				console.log('Valid URL: ' + url);
				
			}
		}
		
	}
	
	function openTab(type,url) { // Create new tab
		
		if(validUrl == true) {
			chrome.tabs.create({ url: type + url }); 	
		}
		
	}
	
	function notifyUser(url) { // Show notification if is not vaild
		
		if(userOptions.contextMenuNote == true && validUrl == false) {
			
			var NotificationId = getRandomId();
	
			chrome.notifications.create(NotificationId, {
				title: 'This page can not be archived, Sorry!',
				iconUrl: '/images/128.png',
				type: 'basic',
				message: url,
			}, function(id) {
				myNotificationID = id;
			});
		}
		
	}
	
	function getRandomId() { // Creates a random ID;
		
		var id = Math.floor(Math.random() * 9007199254740992) + 1;
		return id.toString();
	}
	