	
	// Hard coded options
	var validUrl = true;
	var menuCreated = false;
	
	var options = {
		expression: /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi,
		protocolBlackList: ['chrome:','chrome-extension:','ftp:','file:'],
		hostNameBlackList: ['web.archive.org'],
		saveUrl: "n-https://web.archive.org/save/",
		calendarUrl: "https://web.archive.org/web/*/",
		apiUrl: "https://archive.org/wayback/available?url="	
	}
	
	// User set options - chrome.storage options
	var userOptions = {};
	
	chrome.runtime.onInstalled.addListener(function(details) { // On Install/Update
    
		if(details.reason == "install") {
			console.log("This is a first install!");
		
			chrome.storage.sync.get({ // Fetch user options
				// Use default values
				pagesArchived: 0,
				logNumberArchived: true,
				contextMenu: true,
				contextMenuNote: false
			}, function(items) {
			
				passOptions(items); // Pass options from chrome.storage to var userOptions;
				createMenu(); // Create context menu and pass options
			});
			
		} else if(details.reason == "update") {
			var thisVersion = chrome.runtime.getManifest().version;
			console.log("Updated from " + details.previousVersion + " to " + thisVersion + "!");
			
			chrome.storage.sync.get(function(items) {
			
				passOptions(items); // Pass options from chrome.storage to var userOptions;
				createMenu(); // Create context menu and pass options
			});
		}
	});
	
	chrome.runtime.onStartup.addListener(function() { // On Startup

		chrome.storage.sync.get({ // Fetch user options
			// Use default values
			pagesArchived: 0,
			logNumberArchived: true,
			contextMenu: true,
			contextMenuNote: false
		}, function(items) {
			
			passOptions(items); // Pass options from chrome.storage to var userOptions;
			createMenu(); // Create context menu and pass options
		});
	});
	
	chrome.storage.onChanged.addListener(function(changes, namespace) { // On storage change (user options)

		chrome.storage.sync.get(function(items) {			
			passOptions(items); // Pass options from chrome.storage to var userOptions;
			createMenu(); // Create context menu (if not)
			removeMenu(); // Create context menu (if not)
		
		});

	});
	
	chrome.contextMenus.onClicked.addListener(function(info, tab) { // On click of the context menu link
 
		vaildateUrl(tab.url);
		
		if(validUrl == true) {
			logNumber(); // log number
		}
	
		openTab(tab.url); // open the URL
		
		notifyUser(tab.url); // Show notification if is URL not vaild
	});
	
	
	// Functions	
	function passOptions(data) {  // Pass options from chrome.storage to var userOptions;
		
		userOptions = data;
		
	}
	
	function createMenu() { // Create context menu
		
		if(menuCreated == false && userOptions.contextMenu == true) {
			menuCreated = true;
			
			chrome.contextMenus.create({
				"title": "Archive this page",
				"contexts": ["page"],
				"id": "archive"
			}, function() {
				if (chrome.extension.lastError) {
					console.log("Got expected error: " + chrome.extension.lastError.message);
				}
			});
		} else {
			console.log('Context menu not created (user option)');	
		}
		
	}
	
	function removeMenu() { // Remove set context menu
		
		if(menuCreated == true && userOptions.contextMenu == false) {
			console.log('Context menu removed (user option)');
			
			menuCreated = false;
			
			chrome.contextMenus.removeAll(function() {
				if (chrome.extension.lastError) {
					console.log("Got expected error: " + chrome.extension.lastError.message);
				}
			});
		}
		
	}
	
	function vaildateUrl(url) { //Vaildate Url
		
		validUrl = true; // Default
		
		var parser = document.createElement('a'); // Get URL parts
		parser.href = url;
		
		// Loop through protocol black list
		for (i = 0; i < options.protocolBlackList.length; i++) {
			if(parser.protocol == options.protocolBlackList[i]) { // If current URL and black list protocol match
				validUrl = false;
				break;
			}
		}
		
		// Loop through host name black list
		for (i = 0; i < options.hostNameBlackList.length; i++) { 
			if(parser.hostname == options.hostNameBlackList[i]) { // If current URL and host Name protocol match
				validUrl = false;
				break;
			}
		}
		
		if(validUrl == true) { // If URl passed the protocol black lots check   
			
			// Validate URl with regex
			var regex = new RegExp(options.expression);
		
			if (!url.match(regex)) {
				validUrl = false;
				console.log('Failed URL: ' + url);
			} else {
				console.log('Valid URL: ' + url);
				
			}
		}
		
	}
	
	function openTab(url) { // Create new tab
		
		if(validUrl == true) {
			chrome.tabs.create({ url: options.saveUrl + url }); 	
		}
		
	}
	
	function notifyUser(url) { // Show notification if is not vaild
		
		if(userOptions.contextMenuNote == true && validUrl == false) {
			
			var NotificationId = getRandomId();
	
			chrome.notifications.create(NotificationId, {
				title: 'This page can not be archived, Sorry!',
				iconUrl: '/images/128.png',
				type: 'basic',
				message: url,
			});
		}
		
	}
	
	function getRandomId() { // Creates a random ID;
		
		var id = Math.floor(Math.random() * 9007199254740992) + 1;
		return id.toString();
	}
	
	function fetchOptions() { // Returns var option (used by popup.js only)
		return options;
	}
	
	function logNumber() { // Logs number and opens save tab (used by popup.js & background.js)
	
		chrome.storage.sync.get({
			// Default
			pagesArchived: 0,
		}, function(items) {
			items.pagesArchived++;
			
			chrome.storage.sync.set({'pagesArchived': items.pagesArchived}, function() {
				console.log('number updated');
			});
		});
		
	} 
	